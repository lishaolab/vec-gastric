#!/usr/bin/env python
# coding: utf-8

# In[1]:


import sys, os, time, math, random
import matplotlib.pyplot as plt
from numpy import r_ as r
import numpy as np
import pandas as pd


# In[2]:


import scanpy as sc


# In[3]:


import anndata
# anndata.AnnData


# In[4]:


import scvelo as scv


# In[20]:


# adata=anndata.read_loom('data/alevin.JC.loom')
adatawtf=scv.read('../_data/alevin.LDYS6.IM.3.h5ad')
# adatawtf=scv.read('data/alevin.IMS2.lowq.h5ad')


# In[21]:


adatawtf.layers['spliced']


# In[22]:


adatawtf.layers['unspliced']


# In[23]:


adata=adatawtf.copy()


# In[24]:


adata.obs['clusters']=adata.obs['ident0']


# # 

# In[25]:


scv.settings.verbosity = 3  # show errors(0), warnings(1), info(2), hints(3)
scv.settings.presenter_view = True  # set max width size for presenter view
# scv.set_figure_params('scvelo')  # for beautified visualization
scv.set_figure_params('scvelo',facecolor='white')  # for beautified visualization


# In[26]:


scv.utils.show_proportions(adata)


# In[27]:


scv.pl.proportions(adata)


# # 

# In[28]:


# scv.pp.filter_genes(adata, min_shared_counts = 30)
# scv.pp.normalize_per_cell(adata, enforce = True)
# scv.pp.filter_genes_dispersion(adata, n_top_genes = 2000)
# scv.pp.log1p(adata)
scv.pp.filter_and_normalize(adata, min_shared_counts=20, n_top_genes=2000,enforce=True)


# In[29]:


scv.pp.moments(adata, n_pcs=20, n_neighbors=20)


# In[ ]:





# # stochastic

# In[30]:


scv.tl.velocity(adata)


# In[31]:


scv.tl.velocity_graph(adata)


# In[32]:


scv.pl.velocity_embedding_stream(adata, basis='umap',color='seurat_clusters')


# In[ ]:





# In[52]:


# scv.pl.velocity_embedding_stream(adata, basis='umap',color='ident0',legend_fontsize=16,legend_loc='none',title='',figsize=[5,5],
    # linewidth=1,palette=['#619CFF', '#FF9D46', '#44AC44', '#9B72C1', '#B79F00', '#00BFC4'])
scv.pl.velocity_embedding_stream(adata, basis='umap',color='ident0',legend_fontsize=16,legend_loc='none',title='',figsize=[5,5],
    linewidth=1,palette=['#619CFF', '#FF9D46', '#44AC44', '#9B72C1', '#B79F00', '#00BFC4'],save='2f.pdf')


# In[ ]:





# In[ ]:





# In[ ]:




