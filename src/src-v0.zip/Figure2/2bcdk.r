box::use(Seurat[...], patchwork[...], future[...], furrr[...], Matrix[...])
box::use(IRdisplay[d = display], data.table[fread], plyr[mpv = mapvalues])
box::use(magrittr[..., srn = set_rownames, scn = set_colnames], purrr[sn = set_names])
box::use(tibble[rn2c = rownames_to_column, c2rn = column_to_rownames], stringr[g = str_glue, s = str_c, ss = str_subset])
box::use(base[asdf = as.data.frame, asm = as.matrix, asl = as.list, asc = as.character, asi = as.integer, asd = as.double, asv = as.vector, len = length, nm = names, rn = rownames, cn = colnames, sec = intersect], utils[h = head])
options(max.print = 1000, repr.vector.max.items = 100, future.globals.maxSize = 1000 * 1024^4, future.rng.onMisuse = "ignore", datatable.fread.datatable = FALSE, box.path = '/data/egc21/lab')
RhpcBLASctl::blas_set_num_threads(16)
box::use(test/progressively[...])
plan(multicore, workers = 16)
library(tidyverse)
jlvi_brief = 1

if ("fs" %in% ls()) detach(fs) else fs = new.env()
fs$ata = . %>% as.data.frame %>% t %>% as.data.frame
fs$tb = function(x, ...) base::table(x, useNA = "ifany", ...)
fs$rp = function(w = 8, h = 6) options(repr.plot.width = w, repr.plot.height = h); fs$rp()
fs$ff = function(x, y, f = len) list(sec = f(sec(y, x)), union = f(union(y, x)), only_x = f(setdiff(x, y)), only_y = f(setdiff(y, x)))
fs$RotateAxis = function(angle = 45) theme(axis.text.x = element_text(angle = angle, hjust = ifelse(angle == 0, 0.5, 1), vjust = ifelse(angle == 90, 0.5, 1)))
fs$fwrite = function(x, ..., sep = "\t", row.names = has_rownames(x)) data.table::fwrite(x, ..., sep = sep, row.names = row.names)
fs$dl = function(dt, group.by = NULL, label = T, label.size = 6, shuffle = T, cells.highlight = NULL, raster = ncol(dt) > 20000, ...) suppressMessages(DimPlot(dt, group.by = group.by, label = label, label.size = label.size, shuffle = shuffle, cells.highlight = cells.highlight, raster = raster, ...))
fs$fl = function(dt, gs, order = T, raster = ncol(dt) > 20000, ncol = rep(1:4, c(1, 3, 5, 7))[len(gs)], ...) suppressMessages(FeaturePlot(dt, gs, order = order, ncol = ncol, raster = raster, ...))
fs$vl = function(dt, gs, group.by = NULL, pt.size = 0, ...) VlnPlot(dt, gs, group.by = group.by, pt.size = pt.size, ...)
fs$dtl = function(dt, gs, ...) DotPlot(dt, features = gs, ...) + RotateAxis()
fs$crl = function(corr, col = colorRampPalette(c("#67001F", "#B2182B", "#D6604D", "#F4A582", "#FDDBC7", "#FFFFFF", "#D1E5F0", "#92C5DE", "#4393C3", "#2166AC", "#053061") %>% rev)(200), ...) corrplot::corrplot(corr, col = col, ...)
fs$sl = . %>% unlist %>% sort %>% asl
attach(fs)



# sdf=fread('table.name.211006.txt')
sdf=fread('table.name.211204.txt')

sdf %>% arrange(.[[1]])

# e=future(save(dti,file='data_IM/dti.entero.210818.Rdata'))
# saveRDS(dti@assays$RNA@data,'data_IM/data.rds')
load('IM/data_IM/dti.entero.211020.Rdata')

dt = dti
# dt@meta.data = readRDS("/data/egc21/data/meta.data.integrated.epi.rds")
dt@meta.data = readRDS('~/data/meta.data.entero.211121.rds')

DefaultAssay(dt)='RNA'

df = map_dfc(sdf[,-c(1,6)],~mpv(dt$sample,sdf$sample,.x,F)) %>% srn(cn(dt))
dt %<>% AddMetaData(df)

color.list = c('#9B72C1', '#44AC44', '#FF9D46')
names(color.list) = c('Mix', 'CIM', 'IIM')
cols = c('#B79F00', '#00BFC4', '#619CFF', color.list['CIM'], color.list['Mix'], color.list['IIM'])
names(cols) = c('Stem','PC','Prog','CIM','Mix','IIM')



# DefaultAssay(dt)='RNA'
# DefaultAssay(dt)='integrated'
DefaultAssay(dt)='RNA'
rp(6,4)
DotPlot(dt,features = c('TFF1','MUC5AC','CEACAM6','TACSTD2','KRT7','NMUR2'),scale.by = 'size',cols='RdYlGn')+RotateAxis()+
theme(panel.background = element_rect( fill = "white", colour = NA),
      panel.border = element_rect( fill = NA, colour = "black"),
      panel.grid = element_line( colour = "grey92"),
      panel.grid.minor = element_line( size = rel(0.5)),
      strip.background = element_rect( fill = "grey85", colour = "black"),
      legend.key = element_rect( fill = "white", colour = NA))+
ylab('')+xlab('') + theme(#legend.text = element_text(size = 10),
                 # legend.position = 'right',
                 # legend.key.height = unit(1.4,"cm"),
                 # legend.key.width = unit(1.4,"cm"),
                 axis.text.x = element_text(size = 16),
                 axis.text.y = element_text(size = 16),
                 axis.title.x = element_text(size = 16),
                 axis.title.y = element_text(size = 16))
rp()
# ggsave('Figure/ArticleFigure/Figure2/2b.pdf',width=6,height=4)
# ggsave('Figure/ArticleFigure/Figure2/2b.png',width=6,height=4)





blank <- element_blank()

library(ggpubr)

rp(5,6)
p=VlnPlot(dt,c('SI','LI'),pt.size=0,cols=cols,stack = F,ncol=1,flip=T,idents = c('CIM','Mix','IIM'))&geom_boxplot(width=0.1)&
theme_classic(24)+NoLegend()+RotateAxis(0)+theme(axis.text = element_text(color='black'))

p[[1]]=p[[1]]+ylim(0.05,1.3)+stat_compare_means(label = "p.signif", comparisons = list(c('Mix','IIM'),c('CIM','Mix')),bracket.size = 0.8,size=8,
                                                method.args = list(alternative = "g"),)+
    theme(axis.text.x = blank, axis.title.x = blank, axis.title.y = blank)+ggtitle('')+scale_y_continuous(n.breaks = 5,limits=c(0.05,1.3))

p[[2]]=p[[2]]+ylim(0.20,1.0)+stat_compare_means(label = "p.signif", comparisons = list(c('CIM','Mix'),c('Mix','IIM')),bracket.size = 0.8,size=8,
                                                method.args = list(alternative = "l"),)+
    theme(axis.title.x = blank,axis.text.x=element_text(), axis.title.y = blank)+ggtitle('')
p
# ggsave('Figure/ArticleFigure/Figure2/2d.pdf',width=5,height=6)
# ggsave('Figure/ArticleFigure/Figure2/2d.png',width=5,height=6)
rp()

gsva=readRDS('IM/data_IM/gsva.rds')

gsva %<>% srn(rn(.) %>% str_replace_all('_','-'))

gsva

dt[['gsva']]=CreateAssayObject(gsva)

DefaultAssay(dt)='gsva'

m1=FindMarkers(dt,'IIM',logfc.threshold = 0.1)

m2=FindMarkers(dt,'CIM',logfc.threshold = 0.1)

a=m1 %>% filter(rn(.) %>% str_starts('HALL'),.[2]>0) %>% rn %>% 
c(m2 %>% filter(rn(.) %>% str_starts('HALL'),.[2]>0) %>% rn)

# em=AverageExpression(dti,'gsva',a,slot='counts')$gsva[,c('IIM','Mix','CIM')] %>% 
# em=AverageExpression(dti,'gsva',a,slot='counts')$gsva[,c('Stem','Prog','PC','IIM','Mix','CIM')] %>% 
em=AverageExpression(dt,'gsva',a,slot='counts')$gsva[,c('IIM','Mix','CIM')] %>% 
    srn(rn(.) %>% str_sub(10) %>% str_replace_all('-',' ') %>% str_to_sentence)

em %>% srn(rn(.)%>% s(1:23,'-',.))

rp(3.5,3)
em[c(3,2,6,8,1,7,5,9,   16,10,23,11,19,12,18,22),] %>% pheatmap::pheatmap(filename = 'Figure/ArticleFigure/Figure2/Fig.2c.gsva.3.5x3.png',width = 3.5,height = 3,
    cluster_cols = F,cluster_rows = F,angle_col = 0)
rp()

rp(3.5,3)
em[c(3,2,6,8,1,7,5,9,   16,10,23,11,19,12,18,22),] %>% pheatmap::pheatmap(filename = 'Figure/ArticleFigure/Figure2/Fig.2c.gsva.3.5x3.pdf',width = 3.5,height = 3,
    cluster_cols = F,cluster_rows = F,angle_col = 0)
rp()



library(ggpubr)

rp(5,4)
dt[[c('EGC.score1','ident0')]] %>% filter(ident0%in%c('CIM','IIM','Mix')) %>% ggplot(aes(x=ident0,y=EGC.score1,fill=ident0))+
ylab('')+ggtitle('')+scale_fill_manual(values=color.list)+
geom_violin()+geom_boxplot(width=0.1)+
ylim(-0.05,0.23)+
xlab('wtf')+
theme_classic(24)+
NoLegend()+stat_compare_means(label = "p.signif", comparisons = list(c('Mix','IIM'),c('CIM','IIM')),method.args = list(alternative = "l"),
                              size=8,bracket.size = 0.8)+
theme(axis.title=blank,plot.title=element_text(hjust=.5,face='bold',size=24))+
theme(axis.text = element_text(color='black'))+
theme(plot.title=blank)
# ggsave('Figure/ArticleFigure/Figure2/2k.pdf',width=5,height=4)
# ggsave('Figure/ArticleFigure/Figure2/2k.png',width=5,height=4)
rp()

cols %>% 







df=table(dti@active.ident,dti$sample) %>% sweep(2,colSums(.),'/') %>% as.data.frame.array %>% .['IIM',] %>% ata %>% rn2c('sample') %>% 
mutate(lesion=sample %>% mpv(sdf$sample,sdf$lesion,F),sam=sample %>% mpv(sdf$sample,sdf$sam,F)) 

# df[df$sample=='LDYS9','lesion']='LDYS'

library(ggpubr)

load('Figure/ArticleFigure/Color_Lesion_new.Rdata')

rp(6,5)
ggplot(df,aes(x=lesion,y=IIM,fill=lesion,label=sam))+geom_boxplot()+ geom_point()+ #geom_text()+
scale_fill_manual(values=color.index)+
theme_black(24)+xlab('')+ylab('IIM Proportion')+NoLegend()+ylim(0.05,0.42)+
stat_compare_means(comparisons = list(c('IM','LGD')),method='wilcox',paired = F,method.args = list(alternative = "less"),size=8,bracket.size = 0.8)
# ggsave('Figure/SupplementaryFigure/SupplementaryFigure5/S5i.png',width=6,height=5)
rp()



DefaultAssay(dt)='integrated'
# DefaultAssay(dt)='RNA'

dt@active.ident  %<>% fct_relevel(c('Stem','PC','Prog','CIM','Mix','IIM'))

theme_black = function(base_size = 20, ...) theme_classic(base_size = base_size, ...) + 
    theme(axis.text = element_text(color = "black"), 
          line = element_line(size = 0.5), 
          rect = element_rect(size = 0.5), 
          legend.margin = margin(0,0,0,0),
          plot.title = element_text(hjust = 0.5, face = "bold"))

rp(5,5)
p2=FeatureScatter(dt,'MUC5AC','FABP1',cells = cn(dt)[ dt$ident0%in%c('IIM','Mix','CIM')],pt.size = 1.5,shuffle = T,slot='data')+
theme_black(24)+theme(legend.margin = margin(0,0,0,0),
    legend.key.height = unit(0.8,"cm"),
                  # legend.key.width = unit(0.2,"cm"),
)
p2
# ggsave('Figure/SupplementaryFigure/SupplementaryFigure5/S5d.png',width=5,height=5)
rp()












