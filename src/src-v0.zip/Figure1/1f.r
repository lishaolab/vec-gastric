box::use(Seurat[...], patchwork[...], future[...], furrr[...], Matrix[...])
box::use(IRdisplay[d = display], data.table[fread], plyr[mpv = mapvalues])
box::use(magrittr[..., srn = set_rownames, scn = set_colnames], purrr[sn = set_names])
box::use(tibble[rn2c = rownames_to_column, c2rn = column_to_rownames], stringr[g = str_glue, s = str_c, ss = str_subset])
box::use(base[asdf = as.data.frame, asm = as.matrix, asl = as.list, asc = as.character, asi = as.integer, asd = as.double, asv = as.vector, len = length, nm = names, rn = rownames, cn = colnames, sec = intersect], utils[h = head])
options(max.print = 1000, repr.vector.max.items = 100, future.globals.maxSize = 1000 * 1024^4, future.rng.onMisuse = "ignore", datatable.fread.datatable = FALSE, box.path = '/data/egc21/lab')
RhpcBLASctl::blas_set_num_threads(16)
box::use(test/progressively[...])
plan(multicore, workers = 16)
library(tidyverse)
jlvi_brief = 1

if ("fs" %in% ls()) detach(fs) else fs = new.env()
fs$ata = . %>% as.data.frame %>% t %>% as.data.frame
fs$tb = function(x, ...) base::table(x, useNA = "ifany", ...)
fs$rp = function(w = 8, h = 6) options(repr.plot.width = w, repr.plot.height = h); fs$rp()
fs$ff = function(x, y, f = len) list(sec = f(sec(y, x)), union = f(union(y, x)), only_x = f(setdiff(x, y)), only_y = f(setdiff(y, x)))
fs$RotateAxis = function(angle = 45) theme(axis.text.x = element_text(angle = angle, hjust = ifelse(angle == 0, 0.5, 1), vjust = ifelse(angle == 90, 0.5, 1)))
fs$fwrite = function(x, ..., sep = "\t", row.names = has_rownames(x)) data.table::fwrite(x, ..., sep = sep, row.names = row.names)
fs$dl = function(dt, group.by = NULL, label = T, label.size = 6, shuffle = T, cells.highlight = NULL, raster = ncol(dt) > 20000, ...) suppressMessages(DimPlot(dt, group.by = group.by, label = label, label.size = label.size, shuffle = shuffle, cells.highlight = cells.highlight, raster = raster, ...))
fs$fl = function(dt, gs, order = T, raster = ncol(dt) > 20000, ncol = rep(1:4, c(1, 3, 5, 7))[len(gs)], ...) suppressMessages(FeaturePlot(dt, gs, order = order, ncol = ncol, raster = raster, ...))
fs$vl = function(dt, gs, group.by = NULL, pt.size = 0, ...) VlnPlot(dt, gs, group.by = group.by, pt.size = pt.size, ...)
fs$dtl = function(dt, gs, ...) DotPlot(dt, features = gs, ...) + RotateAxis()
fs$crl = function(corr, col = colorRampPalette(c("#67001F", "#B2182B", "#D6604D", "#F4A582", "#FDDBC7", "#FFFFFF", "#D1E5F0", "#92C5DE", "#4393C3", "#2166AC", "#053061") %>% rev)(200), ...) corrplot::corrplot(corr, col = col, ...)
fs$sl = . %>% unlist %>% sort %>% asl
attach(fs)



load('data/dt.cancer.cell.Rdata')

dt$stage=dt$sam %>% str_sub(end=-2)

load('data/gsva.score.cancer.Rdata')
a=gsva.score
load('data/gsva.score.cancer.GO+KEGG.Rdata')
gsva.score %<>% rbind(a)

gsva.score %<>% srn(rn(.) %>% str_replace_all('_','-'))

dt[['GSVA']]=CreateAssayObject(data=gsva.score)



m=FindMarkers(dt,'EGC','AGC',assay='GSVA',group.by = 'stage')

genes=m %>% filter(avg_log2FC>0) %>% head(50) %>% rn
genes=m %>% filter(avg_log2FC<0) %>% head(50) %>% rn %>% c(genes) 

g=gsva.score

ids = dt$sam %>% unique %>% sort %>% .[c(4:6,1:3)]
em = map(ids, ~rowMeans(g[, dt$sam == .x])) %>% setNames(ids) %>% as.data.frame

rp(12, 15)
pheatmap::pheatmap(em[genes, ] %>% srn(str_to_lower(rn(.)) %>% s(c(1:50,1:50),'-',.)),
    angle_col = 0,
    cluster_rows = F, cluster_cols = F,
    show_rownames = T, show_colnames = T,
)
rp(8, 6)

a=m %>% filter(.[[2]]<0) %>% .[c(3,14,12,13,19),]  %>% rn
a=m %>% filter(.[[2]]>0) %>% .[c(1,48,6,38,4),]  %>% rn %>% c(a)

mat=em[a, ] %>% srn(rn(.) %>% str_sub(6) %>% 
str_replace_all('-',' ') %>% str_to_sentence %>% 
replace(9,'Positive regulation of cell migration by VEGF'))

rp(8.5,6)
mat %>%rn2c %>%
pivot_longer(-1, values_to = 'Mean GSVA score') %>%
ggplot(aes(
    x = name %>% fct_relevel(~ .[c(4:6, 1:3)]),
    y = rowname %>% factor(.,levels=unique(.))
    ,fill = `Mean GSVA score`
)) +
geom_tile() +
# coord_fixed(ratio=2)+
theme_minimal(24) +
scale_y_discrete(position = 'right') +
NoGrid() + RotatedAxis() +
theme(plot.margin = unit(c(0,0,0,1),'cm'))+
scale_fill_gradientn(colors = scales::brewer_pal('div', 7, -1)(11)) +
xlab('') + ylab('') +
theme(legend.position = c(2.5, -0.08)) +
theme(axis.text.x = element_text(color = 'black',vjust=1.2)) +
theme(axis.text.y = element_text(color = 'black')) +
theme(legend.title = element_text(size=20))+
# coord_cartesian(expand = )+
guides(fill = guide_colorbar(direction = 'horizontal', title.position = 'top',barwidth=12,title.hjust = 0.5,title.vjust = 0))
rp()
# ggsave('/data/STAD/VEC_Article_Final/ArticleFigure/Figure1/zfr/1f.pdf',width=8.5,height=6)
# ggsave('/data/STAD/VEC_Article_Final/ArticleFigure/Figure1/zfr/1f.png',width=8.5,height=6)


















