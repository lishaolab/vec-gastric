box::use(Seurat[...], patchwork[...], future[...], furrr[...], Matrix[...])
box::use(IRdisplay[d = display], data.table[fread], plyr[mpv = mapvalues])
box::use(magrittr[..., srn = set_rownames, scn = set_colnames], purrr[sn = set_names])
box::use(tibble[rn2c = rownames_to_column, c2rn = column_to_rownames], stringr[g = str_glue, s = str_c, ss = str_subset])
box::use(base[asdf = as.data.frame, asm = as.matrix, asl = as.list, asc = as.character, asi = as.integer, asd = as.double, asv = as.vector, len = length, nm = names, rn = rownames, cn = colnames, sec = intersect], utils[h = head])
options(max.print = 1000, repr.vector.max.items = 100, future.globals.maxSize = 1000 * 1024^4, future.rng.onMisuse = "ignore", datatable.fread.datatable = FALSE, box.path = '/data/egc21/lab')
RhpcBLASctl::blas_set_num_threads(16)
box::use(test/progressively[...])
plan(multicore, workers = 16)
library(tidyverse)
jlvi_brief = 1

if ("fs" %in% ls()) detach(fs) else fs = new.env()
fs$ata = . %>% as.data.frame %>% t %>% as.data.frame
fs$tb = function(x, ...) base::table(x, useNA = "ifany", ...)
fs$rp = function(w = 8, h = 6) options(repr.plot.width = w, repr.plot.height = h); fs$rp()
fs$ff = function(x, y, f = len) list(sec = f(sec(y, x)), union = f(union(y, x)), only_x = f(setdiff(x, y)), only_y = f(setdiff(y, x)))
fs$RotateAxis = function(angle = 45) theme(axis.text.x = element_text(angle = angle, hjust = ifelse(angle == 0, 0.5, 1), vjust = ifelse(angle == 90, 0.5, 1)))
fs$fwrite = function(x, ..., sep = "\t", row.names = has_rownames(x)) data.table::fwrite(x, ..., sep = sep, row.names = row.names)
fs$dl = function(dt, group.by = NULL, label = T, label.size = 6, shuffle = T, cells.highlight = NULL, raster = ncol(dt) > 20000, ...) suppressMessages(DimPlot(dt, group.by = group.by, label = label, label.size = label.size, shuffle = shuffle, cells.highlight = cells.highlight, raster = raster, ...))
fs$fl = function(dt, gs, order = T, raster = ncol(dt) > 20000, ncol = rep(1:4, c(1, 3, 5, 7))[len(gs)], ...) suppressMessages(FeaturePlot(dt, gs, order = order, ncol = ncol, raster = raster, ...))
fs$vl = function(dt, gs, group.by = NULL, pt.size = 0, ...) VlnPlot(dt, gs, group.by = group.by, pt.size = pt.size, ...)
fs$dtl = function(dt, gs, ...) DotPlot(dt, features = gs, ...) + RotateAxis()
fs$crl = function(corr, col = colorRampPalette(c("#67001F", "#B2182B", "#D6604D", "#F4A582", "#FDDBC7", "#FFFFFF", "#D1E5F0", "#92C5DE", "#4393C3", "#2166AC", "#053061") %>% rev)(200), ...) corrplot::corrplot(corr, col = col, ...)
fs$sl = . %>% unlist %>% sort %>% asl
attach(fs)

color.index=c('N/CAG'='#8AB5C3', 'IM'='#94CA53', 'LGD'='#F8F49C', 'EGC'='#F5852E', 'AGC'='#ED1F24') #%T>% scales::show_col()

# sdf=fread('table.name.211006.txt')
sdf=fread('table.name.211204.txt')

sdf

theme_black = function(base_size = 20, ...) theme_classic(base_size = base_size, ...) + 
    theme(axis.text = element_text(color = "black"), 
          line = element_line(size = 0.5), 
          rect = element_rect(size = 0.5), 
          legend.margin = margin(0,0,0,0),
          plot.title = element_text(hjust = 0.5, face = "bold"))

load("/data/egc21/data/dti.integrated.epi.all.Rdata")

dt = dti
dt@meta.data = readRDS("/data/egc21/data/meta.data.integrated.epi.211224.rds")

DefaultAssay(dt)='RNA'

df = map_dfc(sdf[,-c(1,6)],~mpv(dt$sample,sdf$sample,.x)) %>% asdf %>% srn(cn(dt))
dt %<>% AddMetaData(df)
Idents(dt)=dt$`integrated_snn_res.0.5`

# saveRDS(dt@meta.data,"/data/egc21/data/meta.data.integrated.epi.211224.rds")

color.ct1=c('PMC'='#8DD3C7',
            'GMC'='#FFFFB3',
            'EEC'='#BEBADA',
            'PC'='#B3DE69',
            'Goblet cells'='#80B1D3',
            'Enterocytes'='#FDB462',
            'GC-I'='#FB8072',
            'GC-E'='#FCCDE5' )

blank=element_blank()

rp(8,8)
p1=dl(dt,'ident1',label.size=10,repel=T)+theme_black(20)+
theme(plot.title = blank)+
# theme(axis.text = element_text(color='black',size=18))+
# theme(axis.text = element_text(color='black'))+
# theme(axis.title = element_text(color='black'))+
# scale_shape_manual(values='circle')+
NoLegend()+ scale_color_manual(values=color.ct1)
# p1
# ggsave('Figure/ArticleFigure/Figure1/zfr/1b.epi.pdf',width=8,height=8)
# ggsave('Figure/ArticleFigure/Figure1/zfr/1b.epi.png',width=8,height=8)
rp()

load('/home/zp14/Final_Results/Final_v1031/Preprocess/Final_version/data.merge.immune.final.updatev0109.Rdata')

dt2=data.merge.immune.final

load('/home/zp14/Final_Results/Final_v1031/Preprocess/Final_version/data.merge.stromal.final.updatev0109.Rdata')

dt3=data.merge.stromal.final

color.ct2=scales::brewer_pal(palette = 'Set2')(6)[] %>% sn(dt2@active.ident %>% levels)

rp(4,4)
p2=dl(dt2,raster=T,repel=T,label.size=7)+theme_black(20)+theme(plot.title=blank)+NoLegend()+
scale_color_manual(values=color.ct2)
# p2
rp()

color.ct3=scales::brewer_pal(palette = 'Set1')(8)[c(3,4,5,7,8)] %>% sn(dt3@active.ident %>% levels)

rp(4,4)
p3=dl(dt3,raster=T,repel=T,label.size=7)+theme_black(20)+theme(plot.title=blank)+NoLegend()+
scale_color_manual(values=color.ct3)
# p3
rp()

rp(12,8)
wrap_plots(p1,p2,p3,design='
aab
aac
')
# ggsave('Figure/ArticleFigure/Figure1/zfr/1b.pdf',width=12,height=8)
# ggsave('Figure/ArticleFigure/Figure1/zfr/1b.png',width=12,height=8)
rp()



# dt$tmp dt$`integrated_snn_res.0.5`

dt$tmp2=s(dt$ident1,'-',dt$`integrated_snn_res.0.8`)

a=dt$tmp2 %>% unique %>% asdf %>% mutate(a=.data$'.',b=a %>% str_remove('-\\d*$')) %>% split(~b) %>% 
    map(~arrange(.,a) %>% rowid_to_column %>% mutate(a=s(b,'-',rowid))) %>% bind_rows

dt$tmp3=dt$tmp2 %>% mpv(a$'.',a$a) %>% mpv('GC-E-1','GC-E') %>% str_replace('Enterocytes','MET') %>% str_replace_all('-','_') %>% mpv('GMC_1','GMC_ODAM')

rp(6,5)
dl(dt,'tmp3',label.size=5,repel=T)+NoLegend()+
theme(plot.title = element_blank())
# ggsave('Figure/SupplementaryFigure/SupplementaryFigure4/S4b.png',width=6,height=5)
rp()




df = map_dfc(sdf[,-c(1,6)],~mpv(dt2$sample,sdf$sample,.x,F)) %>% asdf %>% srn(cn(dt2))
dt2 %<>% AddMetaData(df)

df = map_dfc(sdf[,-c(1,6)],~mpv(dt3$sample,sdf$sample,.x,F)) %>% asdf %>% srn(cn(dt3))
dt3 %<>% AddMetaData(df)

ps=list()

dt$batch2=dt$batch %>% mpv(c('batch1','batch2'),c('V2','V3'))
dt2$batch2=dt2$batch %>% mpv(c('batch1','batch2'),c('V2','V3'))
dt3$batch2=dt3$batch %>% mpv(c('batch1','batch2'),c('V2','V3'))
ps$b1=dl(dt,'batch2',F)+ggtitle('Epithelial cells')
ps$b2=dl(dt2,'batch2',F)+ggtitle('Immune cells')
ps$b3=dl(dt3,'batch2',F)+ggtitle('Stromal cells')

rp(5,5)
ps$c1=dl(dt,'lesion',F)+ggtitle('Epithelial cells')
ps$c2=dl(dt2,'lesion',F)+ggtitle('Immune cells')
ps$c3=dl(dt3,'lesion',F)+ggtitle('Stromal cells')
rp()

rp(9,3)
wrap_plots(ps[1:3],ncol=3) & theme(plot.title = element_text(size=20))
rp()
# ggsave('Figure/SupplementaryFigure/SupplementaryFigure3/S3a.png',width=9,height=3)

rp(9,3)
wrap_plots(ps[4:6],ncol=3) & theme(plot.title = element_text(size=20))
rp()
# ggsave('Figure/SupplementaryFigure/SupplementaryFigure3/S3b.png',width=9,height=3)

p1=fl(dt,c('MUC6','MUC5AC','MKI67','FABP1','MUC2','CHGA','CEACAM6'),pt.size=2,raster=T,combine=F)
p2=fl(dt2,c('CD3D','CD79A','CD68','MZB1','TPSAB1','S100A8'),pt.size=2,raster=T,combine=F)
p3=fl(dt3,c('VWF','DCN','ACTA2','PLP1','TAGLN'),pt.size=2,raster=T,combine=F)

# gastric glandular mucous cells (GMCs, marked by MUC6),
# pit mucous cells (PMC, MUC5AC),
# proliferating cells (PC,  MKI67),
# enteroendocrine cells (EEC,  CHGA),
# goblet cells (MUC2),
# gastric cancer cells (GC, CEACAM6),
# endothelial cells (EC,  CD105),
# fibroblasts (Fibro,  DCN),
# vascular smooth muscle cells (MSC, ACTA2),
# gial cells (PLP1),
# pericytes (TAGLN),
# T/NK cells (CD3D),
# plasma cells (marked by MZB1),
# B cells (CD79A),
# mast cells (TPSAB1),
# monocyte/macrophages (CD1C and CD68)
# neutrophils (S100A8)

# rp(27,6)
# p=c(p1,p2,p3)
# wrap_plots(p,nrow = 2,byrow = F) & theme_black(16) & theme(plot.title = element_text(size=20))
# # ggsave('Figure/SupplementaryFigure/SupplementaryFigure3/S3c.png',width=27,height=6)
# rp()

rp(18,9)
p=c(p1,p2,p3)
wrap_plots(p,nrow = 3,byrow = F) & theme_black(14) & theme(plot.title = element_text(size=20))
# ggsave('Figure/SupplementaryFigure/SupplementaryFigure3/S3c.png',width=18,height=9)
rp()





dl(dt,'integrated_snn_res.1.6')

dl(dt,'ident2')

dt$tmp=s(ifelse(dt$ident2=='Cancer cells',dt$ident1,''),'-',ifelse(dt$ident2=='Cancer cells','',dt$ident2)) %>% str_remove('^-|-$')

dt$tmp %>% tb

dt$tmp2=s('C',dt$`integrated_snn_res.0.8`,'-',dt$tmp)
# dt$tmp2=s('C',dt$`integrated_snn_res.0.8`)

# dl(dt,'tmp2')

rp(6,5)
fl(dt,'ODAM',raster=T)
# ggsave('Figure/SupplementaryFigure/SupplementaryFigure4/S4e.png',width=6,height=5)
rp()



# corr1=map(dt$ident.auto %>% unique %>% sn,~
        # dt@reductions$pca@cell.embeddings %>% t %>% .[,dt$ident.auto==.x] %>% rowMeans) %>% asdf %>% cor
corr1=map(dt$tmp2 %>% unique %>% sn %>% .[!str_detect(.,c('GC-I','GC-E','EEC','Goblet cells') %>% s(collapse = '|'))],~
        dt@reductions$pca@cell.embeddings %>% t %>% .[,dt$tmp2==.x] %>% rowMeans) %>% asdf %>% cor

library(ggraph)
library(tidygraph)
graph=as_tbl_graph(corr1 %>% replace(.<0.25,0),directed = F) %N>% 
    # mutate(type = replace(rep('Gastric cells', 16), c(3, 5, 6, 8, 9, 11), 'Metaplastic cells') %>% replace(12, 'ODAM+ cells')) %>%
    # mutate(type = replace(rep('Gastric cells', 13), c(3,5,7,8), 'Intestinal cells') %>% replace(9, 'ODAM+ cells')) %>%
    mutate(idx=1:nrow(corr1)) %>% 
    mutate(type=name %>% str_remove('.*?\\.') %>% str_replace_all('\\.','-')) %>% 
    mutate(num = dt@active.ident %>% table %>% .[rn(corr1)] %>% as.integerteger) %>% 
    mutate(cluster=group_louvain(weights = weight)) %E>%
    mutate(type = ifelse(from == 24 | to == 24, '#666666', 'grey'))

color.ct1=c('PMC'='#8DD3C7',
            'PC'='#B3DE69',
            'GMC'='#FFFFB3',
            'GMC_ODAM'='#FFED6F',
            'Enterocytes'='#FDB462')

graph=graph %N>% mutate(`Cell Type`=type %>% mpv('ODAM--cells','GMC_ODAM') %>% fct_relevel(nm(color.ct1))) %E>% mutate(Correlation=weight)

graph %N>% asdf

rp(6,5)
ggraph(graph,'stress') + 
    geom_edge_link(aes(width = Correlation,color=type)) +
    scale_edge_color_identity()+
    geom_node_point(aes(color = `Cell Type`), size=4) +
    scale_color_manual(values=color.ct1)+
    # geom_node_text(aes(label = name), repel = F, size = 5.5,nudge_x = -0.05,nudge_y = -0.1) +
    # geom_node_text(aes(label = name %>% str_replace_all('\\..*','') %>% mpv('C20','GMC_ODAM')), repel = F, size=6,nudge_y = -0.1,nudge_x = 0.2) +
    scale_size(range = c(3,6))+
    scale_edge_width(range=c(0.6,1.6))+
    theme_graph(base_family='sans',base_size = 16,plot_margin = margin(10, 10, 10, 10))
rp()
# ggsave('Figure/SupplementaryFigure/SupplementaryFigure4/S4f.png',width=6,height=5)





# a=fread('ime/df.immune.txt') %>% pivot_wider(1,2,values_from = 3) %>% c2rn('x') %>% .[,-6]

a=dt2@active.ident %>% tb(dt2$sample %>% factor(levels=dt$sample %>% unique)) %>% t %>% as.data.frame.array
b=dt3@active.ident %>% tb(dt3$sample %>% factor(levels=dt$sample %>% unique)) %>% t %>% as.data.frame.array

# df=tb(dt$sample,dt$ident1) %>% as.data.frame.array %>% bind_cols(a) %>% asm %>% sweep(1,rowSums(.),'/') %>% asdf %>% 
df=tb(dt$sample,dt$ident1) %>% as.data.frame.array %>% bind_cols(a) %>% bind_cols(b) %>% asm %>% 
# sweep(2,colSums(.),'/') %>% 
sweep(1,rowSums(.),'/') %>% 
asdf %>% 
rn2c('sample') %>% mutate(lesion=sample %>% mpv(sdf$sample,sdf$lesion,F),group=sample %>% mpv(sdf$sample,sdf$group,F),sam=sample %>% mpv(sdf$sample,sdf$sam,F)) %>%
pivot_longer(-c(1,'lesion','sam','group'))

ids=c(
"PMC",
"PC",
"GMC",
"Goblet cells",
"Enterocytes",
"EEC",
"GC-E",
"GC-I",
"B cell",
"T/NK cell",
"Mast cell",
"Macro/Mono",
"Neutrophil",
"Plasma cell",
'EC',
'Fibro',
'Gial',
'Pericytes',
'SMC'
) %>% rev
lesions=c('NAG','CAG','IM','LGD','EGC','AGC')
groups=c('N/CAG', 'IM_Per', 'IM_Pro', 'IM_GC', 'LGD_Reg', 'LGD_Per', 'LGD_Pro', 'LGD_GC', 'EGC', 'AGC')

df0=tb(dt$sample,dt$ident1) %>% as.data.frame.array %>% bind_cols(a) %>% bind_cols(b) %>% asm %>% asdf %>% 
rn2c('sample') %>% mutate(lesion=sample %>% mpv(sdf$sample,sdf$lesion,F),group=sample %>% mpv(sdf$sample,sdf$group,F),sam=sample %>% mpv(sdf$sample,sdf$sam,F)) %>%
pivot_longer(-c(1,'lesion','sam','group'))
df0 %<>% mutate(id0=ifelse(name%in%ids[12:19],'Epithelial cells',ifelse(name%in%ids[6:11],'Immune cells','Stromal cells')))

df0 %<>% .[!is.na(.$group),]

df %<>% .[!is.na(.$group),]

scales::brewer_pal(palette = 'Set2')(3)[c(2)] %>% c('Epithelial cells'=.,'Immune cells'='#FCCDE5',
            'Stromal cells'='#D9D9D9')



p0=ggplot(df0,aes(x=group %>% fct_relevel(groups),fill=id0,y=value))+geom_bar(stat='identity')+
scale_fill_manual(values=scales::brewer_pal(palette = 'Set2')(3)[c(2,1,3)])+
# scale_fill_manual(values=scales::brewer_pal(palette = 'Set1')(3)[c(1)] %>% 
                  # c('Epithelial cells'=.,'Immune cells'='#FCCDE5', 'Stromal cells'='#D9D9D9'))+
theme_black(24)+xlab('')+ylab('Number of cells')+labs(fill='Compartments')+theme(axis.text.x = blank,axis.title.x = blank)

p1=ggplot(df0,aes(x=name %>% fct_relevel(ids),fill=name,y=value))+geom_bar(stat='identity')+coord_flip()+
scale_fill_manual(values=color.ct1 %>% c(color.ct2)%>% c(color.ct3))+
theme_black(24)+xlab('')+ylab('Number of cells')+NoLegend()+theme(axis.text.y = blank,axis.title.y = blank)

p2=ggplot(df,aes(x=group %>% fct_relevel(groups),y=name %>% fct_relevel(ids),size=value,color=name))+
scale_color_manual(values=color.ct1 %>% c(color.ct2)%>% c(color.ct3))+
geom_point()+scale_size(range=c(0,6))+theme_black(24)+xlab('')+ylab('')+guides(color='none')+labs(size='Proportion')+RotateAxis()

rp(12,10)
wrap_plots(p0+theme(axis.title.y=element_text(margin = margin(r = -80, unit = "pt"))),
           patchwork::guide_area(),p2,
           p1+theme(axis.title.x=element_text(margin = margin(t = -100, unit = "pt"))),
           ncol = 2,guides = 'collect',widths = c(2,1),heights = c(1,2)) & theme(plot.margin=margin(5,5,5,5,'pt'))
# ggsave('Figure/ArticleFigure/Figure1/zfr/1g.pdf',width=12,height=10)
# ggsave('Figure/ArticleFigure/Figure1/zfr/1g.png',width=12,height=10)
rp()









Idents(dt)=dt$best4 
Idents(dt) %<>% fct_relevel(~.[c(8,6,5,3,9,2,1,4,7,10)])
#%>% fct_relevel(~.[c(1,3,7,2,9,6,8,4,5)])# %>% fct_relevel(~.[c(1:4,7,6,10,5,8,9)])

Idents(dt) %<>% fct_recode('CA7+ Enterocytes'='BEST4+ Enterocytes','CA7- Enterocytes'='Other Enterocytes','ODAM- GMC'='Other GMC')

Idents(dt) %>% levels %>% asl

RotateAxis

rp(8,6)
DotPlot(dt,idents=Idents(dt) %>% levels %>% .[-c(9,10)],features = c('CA7','BEST4','NOTCH2','HES4','SPIB') %>% 
        c('ODAM','LEFTY1','SOD3','SMOC2','THBS2'), #%>% 
        # c('NEUROD1','BEX1','PPP1R17','CTAG2','OLFM1'),
    scale.by='size',cols='RdYlGn')+
# theme_classic(20)+
NoAxes(keep.text=T)+
RotateAxis()+
# annotate('rect',)
annotate("rect", xmin = 0.5, xmax = 10.5, ymin = 0.5, ymax = 4.36, color = 'black', fill = '#FFFFFF00') + # kuang
annotate("rect", xmin = 0.5, xmax = 10.5, ymin = 4.64, ymax = 8.5, color = 'black', fill = '#FFFFFF00') + # kuang
theme(panel.background = element_rect( fill = "white", colour = NA),
      # panel.border = element_rect( fill = NA, colour = "black"),
      panel.grid = element_line( colour = "grey92"),
      panel.grid.minor = element_line( size = rel(0.5)),
      strip.background = element_rect( fill = "grey85", colour = "black"),
      legend.key = element_rect( fill = "white", colour = NA))+
ylab('')+xlab('')+
theme(
    legend.title = element_text(size = 16),
    legend.text = element_text(size = 12),
    # legend.position = 'right',
    # legend.key.height = unit(1.4,"cm"),
    # legend.key.width = unit(1.4,"cm"),
    axis.text.x = element_text(color='black',size = 19.2,hjust=1,vjust=1.05),
    axis.text.y = element_text(color='black',size = 19.2),)
# ggsave('Figure/ArticleFigure/Figure1/zfr/1h.pdf',width=8,height=6)
# ggsave('Figure/ArticleFigure/Figure1/zfr/1h.png',width=8,height=6)
rp()



color.list = c('#9B72C1', '#44AC44', '#FF9D46')
names(color.list) = c('Mix', 'CIM', 'IIM')
cols = c('#B79F00', '#00BFC4', '#619CFF', color.list['CIM'], color.list['Mix'], color.list['IIM'])
names(cols) = c('Stem','PC','Prog','CIM','Mix','IIM')

rp(6,4)
DotPlot(dt,group.by='ident1',features = c('NEUROD1','BEX1','PPP1R17','CTAG2','OLFM1','PHOX2B','DLL3'),
    scale.by='size',cols='RdYlGn')+
NoAxes(keep.text=T)+
RotateAxis()+
scale_y_discrete(limits= c("PC", "PMC", "GMC",  "Goblet cells", "Enterocytes", "EEC", "GC-E","GC-I") %>% rev)+
# scale_y_discrete(limits=~.[c(1,3,4,2,6,5,7,8)])+
# annotate('rect',)
# annotate("rect", xmin = 0.5, xmax = 10.5, ymin = 0.5, ymax = 4.36, color = 'black', fill = '#FFFFFF00') + # kuang
# annotate("rect", xmin = 0.5, xmax = 10.5, ymin = 4.64, ymax = 8.5, color = 'black', fill = '#FFFFFF00') + # kuang
theme(panel.background = element_rect( fill = "white", colour = NA),
      panel.border = element_rect( fill = NA, colour = "black"),
      panel.grid = element_line( colour = "grey92"),
      panel.grid.minor = element_line( size = rel(0.5)),
      strip.background = element_rect( fill = "grey85", colour = "black"),
      legend.key = element_rect( fill = "white", colour = NA))+
ylab('')+xlab('')
# ggsave('Figure/SupplementaryFigure/SupplementaryFigure3/S3h.png',width=6,height=4)
rp()

mat=dt@graphs$integrated_nn %>% t %>% .@i %>% add(1) %>% asi %>% matrix(nrow=20) %>% asdf

mat %<>% scn(cn(dt))

# samples=dt$patient
samples=dt$sam
# samples=dt$batch
# samples=dt$test

plan(multicore, workers = 32)

a=future_map(mat,~samples[.])

# a %<>% future_map(~.x %>% unname %>% factor(levels=unique(samples)) %>% tb)
a %<>% future_map(~.x %>% unname %>% tb) # no diff!!!

b=a %>% future_map(entropy::entropy)

b %<>% unlist

rp(6,4)
tapply(b,dt$ident0,mean) %>% asdf %>% rn2c %>% ggplot(aes(x=rowname %>% fct_relevel(~.[c(1,3,2,4)]),y=.,fill=rowname))+geom_bar(stat='identity')+theme_classic(18)+
    RotateAxis()+NoLegend()+xlab('')+ylab('Entropy')
rp()



rp(6,4)
tapply(b[cn(dt)[ dt$ident0=='Gastric cells']],dt$lesion[cn(dt)[ dt$ident0=='Gastric cells']] %>% mpv(c('NAG','CAG'),c('N/CAG','N/CAG')) ,mean) %>% asdf %>% rn2c %>% scn(c('rn','wtf')) %>% ggplot(aes(x=rn %>% fct_reorder(wtf),y=wtf,fill=rn))+geom_bar(stat='identity')+theme_classic(18)+
    NoLegend()+xlab('')+ylab('Entropy')
rp()

rp(6,4)
tapply(b[cn(dt)[ dt$ident0=='Gastric cells']],dt$lesion[cn(dt)[ dt$ident0=='Gastric cells']] %>% mpv(c('NAG','CAG'),c('N/CAG','N/CAG')) ,mean) %>% asdf %>% rn2c %>% scn(c('rn','wtf'))
rp()

rp(6,4)
tapply(b[cn(dt)[ dt$ident0=='Enterocytes']],dt$lesion[cn(dt)[ dt$ident0=='Enterocytes']] %>% mpv(c('NAG','CAG'),c('N/CAG','N/CAG')) ,mean) %>% asdf %>% rn2c %>% scn(c('rn','wtf')) %>% ggplot(aes(x=rn %>% fct_reorder(wtf),y=wtf,fill=rn))+geom_bar(stat='identity')+theme_classic(18)+
    NoLegend()+xlab('')+ylab('Entropy')
rp()

rp(6,4)
tapply(b[cn(dt)[ dt$ident0=='Enterocytes']],dt$lesion[cn(dt)[ dt$ident0=='Enterocytes']] %>% mpv(c('NAG','CAG'),c('N/CAG','N/CAG')) ,mean) %>% asdf %>% rn2c %>% scn(c('rn','wtf')) 
rp()



save(a,b,file='data/a.b.Rdata')

color.ct2=c('Gastric mucus cells'='#8DD3C7',
            'Secretory cells'='#BEBADA',
            # 'Enterocytes'='#FDB462',
            'MET'='#FDB462',
            'Cancer cells'='#FB8072',
            # 'Immune cells'='#FCCDE5',
            'Immune cells'='#66C2A5',
            # 'Stromal cells'='#D9D9D9'
            'Stromal cells'='#8DA0CB'
           )

scales::brewer_pal(palette = 'Set2')(12) %T>% scales::show_col()

# nonepi=list('Fibroblasts'=1.52849536904764,
#     'Endothelial cells'=2.1329367194861,
#     'T cells'=1.45113011644355,
#      'Monocytes'=1.6603325653695,
#      'Plasma cells'=1.54398269018729,
#     'B cells'=0.879101295432488,
#     'Mast cells'=1.62198972949567,
#     'Neutrophils'=0.804729410953965
#     # 'LGD'=0.5976,
#     # 'IM'=1.0024,
#     # 'N/CAG'=1.0153
#     )
nonepi=list('Immune cells'=1.32687763464708,'Stromal cells'=1.83071604426687)

rp(6,4)
p1=tapply(b,dt$ident0 %>% fct_recode('Gastric mucus cells'='Gastric cells','MET'='Enterocytes'),mean) %>% list(nonepi) %>% unlist %>% sort %>% asdf %>% rn2c %>% scn(c('rn','wtf')) %>% rowid_to_column %>% 
mutate(type=ifelse(rowid%in%c(1,2,3,5),'Epithelial cells','Non-epi\ncells')) %>% 
ggplot(aes(x=rn %>% fct_reorder(wtf),y=wtf,fill=rn))+geom_bar(stat='identity')+facet_grid(~type,scales = 'free',space='free')+
theme_classic(24)+RotateAxis()+NoLegend()+xlab('')+ylab('Entropy')+scale_fill_manual(values = color.ct2)
rp()

blank <- element_blank()

rp(2,4)
p2=list('LGD'=0.5976, 'IM'=1.0024, 'N/CAG'=1.0153 ) %>% asdf %>% ata %>% rn2c %>% scn(c('rn','wtf')) %>% rowid_to_column%>% {.[3,'rn']='N/CAG';.} %>% 
mutate(type='Gastric\nmucus cells') %>% 
ggplot(aes(x=rn %>% fct_relevel(~.[c(3,1,2)]),y=wtf,fill=rn))+geom_bar(stat='identity')+facet_grid(~type,scales = 'free',space='free')+
theme_classic(24)+RotateAxis()+NoLegend()+xlab('')+ylab('')+theme(axis.title.y = blank, axis.title.x = blank)+ylim(c(0,1.8))+scale_fill_manual(values = color.index)
rp()

p3=list('IM'=0.9471230, 'LGD'=1.0666802)%>% asdf %>% ata %>% rn2c %>% scn(c('rn','wtf')) %>% rowid_to_column %>% 
mutate(type='MET\n') %>% 
ggplot(aes(x=rn %>% fct_relevel(~.[c(1,2)]),y=wtf,fill=rn))+geom_bar(stat='identity')+facet_grid(~type,scales = 'free',space='free')+
theme_classic(24)+RotateAxis()+NoLegend()+xlab('')+ylab('')+theme(axis.title.y = blank, axis.title.x = blank)+ylim(c(0,1.8))+scale_fill_manual(values = color.index)

rp(8,6)
# p1|p2+plot_layout(widths = c(3,1),ncol=2)
wrap_plots(list(p1,p2,p3),widths = c(6,3,2)) & theme(plot.margin = margin(5,2,2,2)) & theme(axis.text=element_text(color='black'))
# ggsave('Figure/ArticleFigure/Figure1/zfr/1l.pdf',width=8,height=6)
# ggsave('Figure/ArticleFigure/Figure1/zfr/1l.png',width=8,height=6)
rp()







df1=readxl::read_excel('out/marker+enrich.ca.vs.cf.xlsx',sheet = 3)
df2=readxl::read_excel('out/marker+enrich.ca.vs.cf.xlsx',sheet = 4)
df1 %<>% .[c(2,4,7,9),] %>% rename(rn=1)
df2 %<>% .[c(1:4),] %>% rename(rn=1)

df1

colors = scales::brewer_pal(palette = 8)(4) %>% rev # %>% scales::show_col()
rp(7, 5)
# df = enrich.H50 %>% asdf %>% .[1:6, -c(1, 2)] %>% r2c
ggplot(df1, aes(x = factor(rn, levels = rn %>% rev), y = -log(p.adjust), fill = -log(p.adjust))) +
    geom_bar(stat = 'identity', fill = colors) +
    coord_flip() +
    theme_black(20) +
    theme(axis.text.y = element_blank()) +
    NoLegend() +
    xlab('') +
    annotate('text', x = 1:4 %>% rev, y = 0.1, label = df1$rn %>% str_sub(6), hjust = 0, vjust = 0.5,size=5)
# ggsave('Figure/SupplementaryFigure/SupplementaryFigure4/S4g.png',width=7,height=5)
rp()




