box::use(Seurat[...], patchwork[...], future[...], furrr[...], Matrix[...])
box::use(IRdisplay[d = display], data.table[fread], plyr[mpv = mapvalues])
box::use(magrittr[..., srn = set_rownames, scn = set_colnames], purrr[sn = set_names])
box::use(tibble[rn2c = rownames_to_column, c2rn = column_to_rownames], stringr[g = str_glue, s = str_c, ss = str_subset])
box::use(base[asdf = as.data.frame, asm = as.matrix, asl = as.list, asc = as.character, asi = as.integer, asd = as.double, asv = as.vector, len = length, nm = names, rn = rownames, cn = colnames, sec = intersect], utils[h = head])
options(max.print = 1000, repr.vector.max.items = 100, future.globals.maxSize = 1000 * 1024^4, future.rng.onMisuse = "ignore", datatable.fread.datatable = FALSE, box.path = '/data/egc21/lab')
RhpcBLASctl::blas_set_num_threads(16)
box::use(test/progressively[...])
plan(multicore, workers = 16)
library(tidyverse)
jlvi_brief = 1

if ("fs" %in% ls()) detach(fs) else fs = new.env()
fs$ata = . %>% as.data.frame %>% t %>% as.data.frame
fs$tb = function(x, ...) base::table(x, useNA = "ifany", ...)
fs$rp = function(w = 8, h = 6) options(repr.plot.width = w, repr.plot.height = h); fs$rp()
fs$ff = function(x, y, f = len) list(sec = f(sec(y, x)), union = f(union(y, x)), only_x = f(setdiff(x, y)), only_y = f(setdiff(y, x)))
fs$RotateAxis = function(angle = 45) theme(axis.text.x = element_text(angle = angle, hjust = ifelse(angle == 0, 0.5, 1), vjust = ifelse(angle == 90, 0.5, 1)))
fs$fwrite = function(x, ..., sep = "\t", row.names = has_rownames(x)) data.table::fwrite(x, ..., sep = sep, row.names = row.names)
fs$dl = function(dt, group.by = NULL, label = T, label.size = 6, shuffle = T, cells.highlight = NULL, raster = ncol(dt) > 20000, ...) suppressMessages(DimPlot(dt, group.by = group.by, label = label, label.size = label.size, shuffle = shuffle, cells.highlight = cells.highlight, raster = raster, ...))
fs$fl = function(dt, gs, order = T, raster = ncol(dt) > 20000, ncol = rep(1:4, c(1, 3, 5, 7))[len(gs)], ...) suppressMessages(FeaturePlot(dt, gs, order = order, ncol = ncol, raster = raster, ...))
fs$vl = function(dt, gs, group.by = NULL, pt.size = 0, ...) VlnPlot(dt, gs, group.by = group.by, pt.size = pt.size, ...)
fs$dtl = function(dt, gs, ...) DotPlot(dt, features = gs, ...) + RotateAxis()
fs$crl = function(corr, col = colorRampPalette(c("#67001F", "#B2182B", "#D6604D", "#F4A582", "#FDDBC7", "#FFFFFF", "#D1E5F0", "#92C5DE", "#4393C3", "#2166AC", "#053061") %>% rev)(200), ...) corrplot::corrplot(corr, col = col, ...)
fs$sl = . %>% unlist %>% sort %>% asl
attach(fs)

library(ggraph)
library(tidygraph)

library(ggraph)
library(tidygraph)

load('data/dt.L5.epi.Rdata')

dt %<>% FindNeighbors(dims=1:20) %>% FindClusters(resolution = 1.2)

dt %<>% .[,Idents(.)!=14]

dt %<>% {suppressWarnings(SCTransform(.))} %>% RunPCA(verbose = F) %>% FindNeighbors(dims=1:20) %>% FindClusters %>% RunUMAP(dims=1:20)

dt$ident.auto %<>% mpv('SMOC2','ODAM',F)
dt$ident.auto %<>% mpv('PRR4','MUC6',F)

dt %<>% RegroupIdents('ident.auto')

# saveRDS(dt,'data/dt.L5.epi.rds')
dt=readRDS('data/dt.L5.epi.rds')
dt$ident1=Idents(dt)

dt$ident1 %>% asc %>% unique %>% cat

Idents(dt)=dt$ident1
dt %<>% RenameIdents(
'PGA3'='GMC_1',
'GKN1'='PMC_1',
'CEACAM6'='IIM',
'RGS5'='PMC_2',
'FABP1'='CIM_1',
'GSTP1'='PMC_3',
'TOP2A'='PC_IM',
'RNF186'='CIM_2',
# 'ODAM'='GMC_ODAM',
'ODAM'='ODAM',
'HIST1H1B'='PMC_PC',
'AQP5'='GMC_2',
'MUC6'='GMC_3',
'SRGN'='PMC_4'
)

# saveRDS(dt,'Figure/ArticleFigure/Figure1/dt.L5.ODAM.cor.newtork.rds')

# corr1=map(dt$ident.auto %>% unique %>% sn,~
        # dt@reductions$pca@cell.embeddings %>% t %>% .[,dt$ident.auto==.x] %>% rowMeans) %>% asdf %>% cor
corr1=map(dt@active.ident %>% unique %>% sn,~
        dt@reductions$pca@cell.embeddings %>% t %>% .[,dt@active.ident==.x] %>% rowMeans) %>% asdf %>% cor

graph=as_tbl_graph(corr1 %>% replace(.<0.01,0),directed = F) %N>% 
    # mutate(type = replace(rep('Gastric cells', 16), c(3, 5, 6, 8, 9, 11), 'Metaplastic cells') %>% replace(12, 'ODAM+ cells')) %>%
    mutate(type = replace(rep('Gastric cells', 13), c(3,5,7,8), 'Enterocytes') %>% replace(9, 'ODAM+')) %>%
    mutate(num = dt@active.ident %>% table %>% .[rn(corr1)] %>% as.integer) %>% 
    mutate(cluster=group_louvain(weights = weight)) %E>%
    mutate(type = ifelse(from == 9 | to == 9, '#555555', 'grey'))

# graph=graph %N>% mutate(type2=name %>% str_remove('(_\\d)+')  %>% str_remove('.*_(?=PC)')) %E>% mutate(Correlation=weight)
graph=graph %N>% mutate(type2=name %>% str_remove('(_\\d)+')  %>% str_remove('.*_(?=PC)') %>% str_remove('(?<=PC).*')  %>% str_replace('.*IM.*','IM')) %E>% mutate(Correlation=weight)


graph %N>% asdf

color.ct1=c('PMC'='#8DD3C7',
            'GMC'='#FFFFB3',
            'PC'='#B3DE69',
            # 'GMC_ODAM'='#FFED6F',
            'ODAM'='#FFED6F',
            'IM'='#FDB462')



rp(8,6)
ggraph(graph,'stress') + 
    geom_edge_link(aes(width = Correlation,color=type)) +
    scale_edge_color_identity()+
    geom_node_point(aes(color = type2),size=6) +
    # geom_node_text(aes(label = name), repel = F, size = 5.5,nudge_x = -0.05,nudge_y = -0.1) +
    geom_node_text(aes(label = name), repel = T,size=8) +
    scale_color_manual(values=color.ct1)+
    scale_size(range = c(3,6))+
    scale_edge_width(range=c(0.6,1.6))+
    guides(color='none')+
    theme_graph(base_family='sans',base_size = 24,plot_margin = margin(10, 10, 10, 10))
rp()
# ggsave('Figure/ArticleFigure/Figure1/zfr/1j.pdf',width=8,height=6)
# ggsave('Figure/ArticleFigure/Figure1/zfr/1j.png',width=8,height=6)
















