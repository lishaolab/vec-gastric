box::use(Seurat[...], patchwork[...], future[...], furrr[...], Matrix[...])
box::use(IRdisplay[d = display], data.table[fread], plyr[mpv = mapvalues])
box::use(magrittr[..., srn = set_rownames, scn = set_colnames], purrr[sn = set_names])
box::use(tibble[rn2c = rownames_to_column, c2rn = column_to_rownames], stringr[g = str_glue, s = str_c, ss = str_subset])
box::use(base[asdf = as.data.frame, asm = as.matrix, asl = as.list, asc = as.character, asi = as.integer, asd = as.double, asv = as.vector, len = length, nm = names, rn = rownames, cn = colnames, sec = intersect], utils[h = head])
options(max.print = 1000, repr.vector.max.items = 100, future.globals.maxSize = 1000 * 1024^4, future.rng.onMisuse = "ignore", datatable.fread.datatable = FALSE, box.path = '/data/egc21/lab')
RhpcBLASctl::blas_set_num_threads(16)
box::use(test/progressively[...])
plan(multicore, workers = 16)
library(tidyverse)
jlvi_brief = 1

if ("fs" %in% ls()) detach(fs) else fs = new.env()
fs$ata = . %>% as.data.frame %>% t %>% as.data.frame
fs$tb = function(x, ...) base::table(x, useNA = "ifany", ...)
fs$rp = function(w = 8, h = 6) options(repr.plot.width = w, repr.plot.height = h); fs$rp()
fs$ff = function(x, y, f = len) list(sec = f(sec(y, x)), union = f(union(y, x)), only_x = f(setdiff(x, y)), only_y = f(setdiff(y, x)))
fs$RotateAxis = function(angle = 45) theme(axis.text.x = element_text(angle = angle, hjust = ifelse(angle == 0, 0.5, 1), vjust = ifelse(angle == 90, 0.5, 1)))
fs$fwrite = function(x, ..., sep = "\t", row.names = has_rownames(x)) data.table::fwrite(x, ..., sep = sep, row.names = row.names)
fs$dl = function(dt, group.by = NULL, label = T, label.size = 6, shuffle = T, cells.highlight = NULL, raster = ncol(dt) > 20000, ...) suppressMessages(DimPlot(dt, group.by = group.by, label = label, label.size = label.size, shuffle = shuffle, cells.highlight = cells.highlight, raster = raster, ...))
fs$fl = function(dt, gs, order = T, raster = ncol(dt) > 20000, ncol = rep(1:4, c(1, 3, 5, 7))[len(gs)], ...) suppressMessages(FeaturePlot(dt, gs, order = order, ncol = ncol, raster = raster, ...))
fs$vl = function(dt, gs, group.by = NULL, pt.size = 0, ...) VlnPlot(dt, gs, group.by = group.by, pt.size = pt.size, ...)
fs$dtl = function(dt, gs, ...) DotPlot(dt, features = gs, ...) + RotateAxis()
fs$crl = function(corr, col = colorRampPalette(c("#67001F", "#B2182B", "#D6604D", "#F4A582", "#FDDBC7", "#FFFFFF", "#D1E5F0", "#92C5DE", "#4393C3", "#2166AC", "#053061") %>% rev)(200), ...) corrplot::corrplot(corr, col = col, ...)
fs$sl = . %>% unlist %>% sort %>% asl
attach(fs)

sdf=fread('~/lab/egc/table.name.211204.txt')

sdf

# path='~/data/raw/'
path='~/data/raw.SCT/'

files=dir(path,full.names = T) %>% ss('dt')
sams=dir(path) %>% ss('dt') %>% str_sub(4,-7) %>% sn

plan(multicore, workers = 32)

dts=future_map(files,~{load(.x);dt}) %>% sn(sams)

dts$CAG$ident1=dts$CAG$`RNA_snn_res.0.5`

dts$NAG$ident1=dts$NAG$`RNA_snn_res.0.5`

dts$IMS1$sample=dts$IMS1$batch

dts$LDYS1$sample=NULL
dts$HDYS3$sample=NULL
dts$LDYS8$sample=NULL

dts$LDYS1$ident1=dts$LDYS1$`SCT_snn_res.0.8`

dts %<>% map(~{Idents(.x)=.x$ident1;.x})

plan(list(tweak(multicore, workers = 8), tweak(multicore, workers = 4)))

mss=future_map(nm(dts) %>% sn,~{
    dt=dts[[.x]]
    ms=future_map(dt$ident1 %>% unique %>% sn,~FoldChange(dt,.x,group.by = 'ident1') %>% filter(abs(.[[1]]) > 1))
})

genes.hfcs = mss %>% map(~.x %>% map(rn2c) %>% bind_rows %>% arrange(-abs(.[[2]])) %>% filter(abs(.[[2]]) > 1.5) %>% 
                         .$rowname %>% unique %>% .[1:min(500, len(.))])

ems=dts %>% map(~AverageExpression(.x,'RNA',c('TPSAB1','PTPRC','CD79A','EPCAM','DCN','VIM'),group.by = 'ident1') %>% .$RNA %>% ata)

ems$LDYS1$TPSAB1=0
ems$LDYS1 %<>% .[,c('TPSAB1','PTPRC','CD79A','EPCAM','DCN','VIM')]

ref.identss=map(ems,~pmap_lgl(.x,~max(..1,..2,..3)>max(..4,..5) & ..6>..4) %>% {rn(.x)[.]})

ref.cellss=imap(dts,~cn(.x)[ .x$ident1%in%ref.identss[[.y]]])



genome='hg19'
source("~/lab/egc/cnv/cnv.R")

plan(multicore, workers = 32)
cnv.scores = future_pmap(list(dts, ref.cellss, genes.hfcs), ~{
    # dt=dts[[.x]]
    # gsms = getgsms(dt, ref.cellss[[.x]], genes.hfcs[[.x]])
    gsms = getgsms(..1, ..2, ..3)
    gsm = do.call(rbind, gsms) %>% sweep(2, colMeans(.)) %>% pmax(-0.2) %>% pmin(0.2)
    cnv.score = apply(gsm, 2, var)
})

wtf=c(1:4,6,5,8,7,9:13,16:24,25,27:33,35:39,41:44,46:48,50:53)
a=sdf %>% arrange(.[[1]]) %>% rowid_to_column %>% .[[2]]

sdf %>% arrange(.[[1]]) %>% rowid_to_column

cs=map2(dts %>% nm %>% sn, cnv.scores,~{
    dt=dts[[.x]]
    cnv.score=list(.y)
    if ('sample' %in% cn(dt@meta.data) && n_distinct(dt$sample)<100){
        cnv.score=split(.y,dt$sample) %>% .[sort(nm(.))]
    }
    cnv.score
}) %>% unlist(recursive = F) %>% .[wtf] %>% sn(a)

identss=imap(dts,~{
    dt=.x
    a=list(dt$ident1)
    if ('sample' %in% cn(dt@meta.data) && n_distinct(dt$sample)<100){
        a=split(dt$ident1,dt$sample)
    }
    a
}) %>% unlist(recursive = F) %>% .[wtf] %>% sn(a)



wtf=c(1:4,6,5,8,7,9:13,16:24,25,27:33,35:39,41:44,46:48,50:53)
a=sdf %>% arrange(.[[1]]) %>% rowid_to_column %>% .[[2]]

dtes=imap(dts,~{
    dt=.x
    a=list(dt)
    if ('sample' %in% cn(dt@meta.data) && n_distinct(dt$sample)<100){
        a=SplitObject(dt,'sample') %>% .[sort(nm(.))]
    }
    a
}) %>% unlist(recursive = F) %>% .[wtf] %>% sn(a)

plan(multicore, workers = 16)
dtes %<>% map(~.x %>% FindVariableFeatures %>% ScaleData %>% RunPCA(verbose = F) %>% FindNeighbors %>% FindClusters)

plan(multicore, workers = 32)

dtes=future_map(dir('~/data/raw46.SCT/',full.names = T),~{a=load(.x);get(a)})

dtes %<>% sn(dir('~/data/raw46.SCT/') %>% str_sub(5,-7))

identss=imap(dtes,~{
    .x@active.ident
})

# save(ref.identss,ref.cellss,identss,file='cnv/data/ref.Rdata')
load('cnv/data/ref.Rdata')

cnv.rel = map(nm(cs) %>% sn, ~{
    idents=identss[[.x]]
    sam=.x %>% str_remove('_.*') %>% mpv(c('IMS2','NOR'),c('IMS1','NAG'),F)
    cnv.rel=cs[[.x]] 
    max.ident=tapply(cnv.rel, idents, mean) %>% which.max %>% names
    data.frame(cnv=mean(cnv.rel[idents==max.ident]/mean(cnv.scores[[sam]][ ref.cellss[[sam]]])),
               sample=.x,
               sam=.x %>% mpv(sdf[[1]],sdf[[2]],F) %>% s(' (',.x,')')) #%>% mean
}) %>% bind_rows

cnv.rel %<>% mutate(stage=sam %>% str_remove_all('\\d.*|ca_') %>% mpv(c('NAG','CAG'),'N/CAG' %>% rep(2))%>% fct_relevel(~sort(.) %>% .[c(5,3,4,2,1)]))
cnv.rel %<>% mutate(group=sample %>% mpv(sdf$sample,sdf$group))

library(ggpubr)

cnv.rel %<>% .[-10,]

cnv.rel %<>% filter(group!='NA')

cnv.rel %>% arrange(stage)

load('Figure/ArticleFigure/Color_Lesion_new.Rdata')

theme_black = function(base_size = 20, ...) theme_classic(base_size = base_size, ...) + 
    theme(axis.text = element_text(color = "black"), 
          line = element_line(size = 0.5), 
          legend.margin = margin(0,0,0,0),
          plot.title = element_text(hjust = 0.5, face = "bold"))

rp(4,6)
    ggplot(cnv.rel,aes(x=stage,y=cnv,color=stage,label=sam))+
    geom_boxplot()+
    geom_point()+
    stat_compare_means(comparisons = list(c('N/CAG','IM'),c('IM','LGD'),c('LGD','EGC'),c('EGC','AGC')),method='wilcox',bracket.size = 0.8,label.y=seq(3.4,4.6,0.3),
                       label='p.format',paired = F,method.args = list(alternative = "l"),size=6)+
    theme_black(24)+
    ylim(1.2,4.6) +
    scale_color_manual(values=color.index)+
    NoLegend()+RotatedAxis()+
    xlab('')+ylab('Normalized CNV score')#+ylim(c(0,10))
rp()



theme_black = function(base_size = 20, ...) theme_classic(base_size = base_size, ...) + 
    theme(axis.text = element_text(color = "black"), 
          line = element_line(size = 0.5), 
          rect = element_rect(size = 0.5), 
          legend.margin = margin(0,0,0,0),
          plot.title = element_text(hjust = 0.5, face = "bold"))

rp(8,4)
    ggplot(cnv.rel,aes(x=group %>% fct_relevel(~.[c(10,4,5,3,9,7,8,6,2,1)]),y=cnv,color=group,label=sam))+
    geom_boxplot()+
    geom_point()+#geom_violin(scale='width')+#geom_jitter(size=0.01)+
    theme_black(20)+
    facet_grid(~stage,scales = 'free',space = 'free')+
    NoLegend()+RotatedAxis()+
    xlab('')+ylab('Normalized CNV score')#+ylim(c(0,10))
rp()
# ggsave('Figure/SupplementaryFigure/SupplementaryFigure3/S3x.png',width=8,height=4)







epi.identss=list(
'HDYS1_CAN'=c(2,7),
'AGC2_CAN'=c(0,1,8),
'HDYS2_CAN'=c(3),
'AGC1_CAN'=c(1,2,7),
'AGC5_CAN'=c(4),
'AGC7_CAN'=c(7),
'AGC5_CAN_EEC'=c(3)
)

gsms=map(epi.identss %>% nm %>% sn,~{
    wtf=.x
    gsms=gsmss[[.x %>% str_remove('_.*$')]]
    
    dt=dtes[[.x %>% str_remove('_EEC')]]
    set.seed(0)
    
    cells=cn(dt)[ dt@active.ident%in%epi.identss[[.x]]] %>% sample(min(500,len(.)))
    # cells=cn(dt)[ dt@active.ident%in%cc.identss[[.x]]] %>% sample(min(200,len(.)))
    gsms %>% map(~.[,cells] %>% scn(s(wtf,'.',cn(.))))
})

# gsms$AGC2_CAN %<>% map(~.x*1.5)

idents=imap(gsms,~.[[1]] %>% cn %>% sn(rep(.y,len(.)),.)) %>% unname %>% unlist

gsms = map(1:23, ~do.call(cbind, map(gsms, .x)))

idxs = gsms %>% map(~ifelse(is.matrix(.x), nrow(.x), 0L)) %>% map(~list(1:(.x%/%2), (.x%/%2 + 1):.x))
cnv.status = gsms %>% map2(idxs, ~list(colMeans(.x[.y[[1]], ]), colMeans(.x[.y[[2]], ]))) %>% asdf %>% scn(s('x',c(1:22,'X') %>% rep(each = 2),c('p','q')))
# cells = idents %>% split(.,.) %>% map(nm) %>% .[unique(idents) %>% sort]
cells = idents %>% split(.,.) %>% map(nm) %>% 
    .[c('HDYS1_CAN', 'AGC2_CAN', 'HDYS2_CAN', 'AGC1_CAN', 'AGC5_CAN', 'AGC7_CAN', 'AGC5_CAN_EEC') %>% rev]
ids = imap(cells,~cnv.status[.x,] %>% .[ hclust(dist(.))$order,] %>% rn %>% {sn(rep(.y,len(.)), .)}) %>% unname %>% unlist 

ids %<>% mpv(epi.identss %>% nm,c('EGC1','EGC2','EGC3','AGC1','AGC2','AGC3_1','AGC2_EEC'))



heatmap.cnv = function(main, gsms, idents, zlim = 0.2, sort = F) {
    gsm = do.call(rbind, gsms) %>% pmax(-zlim) %>% pmin(zlim) %>% .[, nm(idents)]

    par(mar = c(4, 8, 2, 0.5), cex = 1)
    pcol <- rev(RColorBrewer::brewer.pal(11, "RdBu")) %>% colorRampPalette

    image(gsm, col = pcol(256), axes = F, useRaster = T, main = main, breaks = seq(-zlim, zlim, length.out = 257))

    widths = map_int(gsms, ~ifelse(is.matrix(.x), nrow(.x), 0L)) %>% divide_by(sum(.))
    wtf = c(0, cumsum(widths))
    wtf2 = map_dbl(1:c(length(wtf) - 1), ~(wtf[.] + wtf[. + 1])/2)
    text(wtf2[-c(13, 15, 21)], y = -0.02, chrs[-c(13, 15, 21)], xpd = T,cex=1.25)
    for (w in cumsum(widths)) lines(c(w, w), c(0, 1))

    heights = idents %>% table %>% .[unique(idents)] %>% as.integer %>% divide_by(sum(.))
    wtf = c(0, cumsum(heights))
    wtf2 = map_dbl(1:c(length(wtf) - 1), ~(wtf[.] + wtf[. + 1])/2)
    axis(2, at = wtf2, label = unique(idents), las = 1, tick = F, pos = NULL,cex.axis=1.25)
    for (h in cumsum(heights)) lines(c(0, 1), c(h, h))

    par(cex = 1.2)
    text(0.5, y = -0.08, "Chrs", xpd = T,cex=1.5)
    # text(-0.23, y = 0.5, "Cells", xpd = T, srt = 90)
    invisible(gsm)
}

# jpeg(g('cnv/plot/Cancer cell 211218'),8,6,'in',res=480)
heatmap.cnv('', gsms, ids, 0.2)
dev.off()





epi.identss=list(
# 'IMS1'=c(3,4,5,7),
'IMS1'=c(3,7),
'IMW3'=c(2),
'LDYS4'=c(2,3,6)
)

gsms=map(epi.identss %>% nm %>% sn,~{
    wtf=.x
    gsms=gsmss[[.x %>% str_remove('_.*$')]]
    
    dt=dtes[[.x %>% str_remove('_EEC')]]
    set.seed(0)
    
    cells=cn(dt)[ dt@active.ident%in%epi.identss[[.x]]] %>% sample(min(500,len(.)))
    # cells=cn(dt)[ dt@active.ident%in%cc.identss[[.x]]] %>% sample(min(200,len(.)))
    gsms %>% map(~.[,cells] %>% scn(s(wtf,'.',cn(.))))
})

# gsms$AGC2_CAN %<>% map(~.x*1.5)

idents=imap(gsms,~.[[1]] %>% cn %>% sn(rep(.y,len(.)),.)) %>% unname %>% unlist

gsms = map(1:23, ~do.call(cbind, map(gsms, .x)))

idxs = gsms %>% map(~ifelse(is.matrix(.x), nrow(.x), 0L)) %>% map(~list(1:(.x%/%2), (.x%/%2 + 1):.x))
cnv.status = gsms %>% map2(idxs, ~list(colMeans(.x[.y[[1]], ]), colMeans(.x[.y[[2]], ]))) %>% asdf %>% scn(s('x',c(1:22,'X') %>% rep(each = 2),c('p','q')))
# cells = idents %>% split(.,.) %>% map(nm) %>% .[unique(idents) %>% sort]
cells = idents %>% split(.,.) %>% map(nm)# %>% 
    # .[c('HDYS1_CAN', 'AGC2_CAN', 'HDYS2_CAN', 'AGC1_CAN', 'AGC5_CAN', 'AGC7_CAN', 'AGC5_CAN_EEC') %>% rev]
ids = imap(cells,~cnv.status[.x,] %>% .[ hclust(dist(.))$order,] %>% rn %>% {sn(rep(.y,len(.)), .)}) %>% unname %>% unlist 

# ids %<>% mpv(epi.identss %>% nm,c('EGC1','EGC2','EGC3','AGC1','AGC2','AGC3_1','AGC2_EEC'))
ids %<>% mpv(sdf$sample,sdf$sam,F)

# jpeg(g('cnv/plot/IM 211218.jpg'),8,6,'in',res=480)
heatmap.cnv('', gsms, ids, 0.2)
# dev.off()






