invisible(lapply(c("Seurat", "patchwork", "future", "furrr", "Matrix", "magrittr", "tidyverse"), library, character.only = T))
box::use(magrittr[srn = set_rownames, scn = set_colnames], purrr[sn = set_names])
box::use(IRdisplay[d = display], data.table[fread], plyr[mpv = mapvalues])
box::use(base[asdf = as.data.frame, asm = as.matrix, asl = as.list, asc = as.character, asi = as.integer, asd = as.double, asv = as.vector, len = length, nm = names, rn = rownames, cn = colnames, sec = intersect], utils[h = head])
box::use(tibble[rn2c = rownames_to_column, c2rn = column_to_rownames], stringr[g = str_glue, s = str_c, ss = str_subset, sb = str_sub])
options(max.print = 1000, repr.vector.max.items = 100, future.globals.maxSize = 1000 * 1024^4, future.rng.onMisuse = "ignore", datatable.fread.datatable = FALSE, box.path = '~/lab')
RhpcBLASctl::blas_set_num_threads(4)
box::use(test/progressively[...])
plan(multicore, workers = 4)
jlvi_brief = 1

if ("fs" %in% ls()) detach(fs) else fs = new.env()
fs$ata = . %>% as.data.frame %>% t %>% as.data.frame
fs$tb = function(x, ...) base::table(x, useNA = "ifany", ...)
fs$rp = function(w = 8, h = 6) options(repr.plot.width = w, repr.plot.height = h); fs$rp()
fs$ff = function(x, y, f = len) list(sec = f(sec(y, x)), union = f(union(y, x)), only_x = f(setdiff(x, y)), only_y = f(setdiff(y, x)))
fs$RotateAxis = function(angle = 45) theme(axis.text.x = element_text(angle = angle, hjust = ifelse(angle == 0, 0.5, 1), vjust = ifelse(angle == 90, 0.5, 1)))
fs$fwrite = function(x, ..., sep = "\t", row.names = has_rownames(x)) data.table::fwrite(x, ..., sep = sep, row.names = row.names)
fs$dl = function(dt, group.by = NULL, label = T, label.size = 6, shuffle = T, cells.highlight = NULL, raster = ncol(dt) > 20000, ...) suppressMessages(DimPlot(dt, group.by = group.by, label = label, label.size = label.size, shuffle = shuffle, cells.highlight = cells.highlight, raster = raster, ...))
fs$fl = function(dt, gs, order = T, raster = ncol(dt) > 20000, ncol = rep(1:4, c(1, 3, 5, 7))[len(gs)], ...) suppressMessages(FeaturePlot(dt, gs, order = order, ncol = ncol, raster = raster, ...))
fs$vl = function(dt, gs, group.by = NULL, pt.size = 0, ...) VlnPlot(dt, gs, group.by = group.by, pt.size = pt.size, ...)
fs$dtl = function(dt, gs, ...) DotPlot(dt, features = gs, ...) + RotateAxis()
fs$crl = function(corr, col = colorRampPalette(c("#67001F", "#B2182B", "#D6604D", "#F4A582", "#FDDBC7", "#FFFFFF", "#D1E5F0", "#92C5DE", "#4393C3", "#2166AC", "#053061") %>% rev)(200), ...) corrplot::corrplot(corr, col = col, ...)
fs$sl = . %>% unlist %>% sort %>% asl
attach(fs)



dt=readRDS('velo/_data/dtee.HDYS4.alevin-fry.rds')

gsva=readRDS('nmf/data/gsva.score.H4.G.rds')
gsva.go=readRDS('nmf/data/gsva.score.GO.H4.G.rds')

dt@assays$gsva=NULL
dt@assays$gsvago=NULL

dt[['gsva']]=CreateAssayObject(gsva)
dt[['gsvago']]=CreateAssayObject(gsva.go)

sam='HDYS4'

Idents(dt) = dt$SCT_snn_res.0.8
dt %<>% RenameIdents(
'0'='GMC',
'1'='PMC',
'2'='PC',
'3'='VEC',
'4'='PMC',
'5'='PMC'
)
dt$ident1 = Idents(dt)



DefaultAssay(dt)='RNA'

# dt$cytotrace=1-dt$cytotrace
# dt$cytotrace=dt$cytotrace-1
dt$cytotrace=1-dt$cytotrace

rp(6,3)
p=(fl(dt,c('VEC1'))+scale_color_gradientn(colors=scales::brewer_pal(palette = 'RdYlGn')(11) %>% rev)+ggtitle('VEC Score'))|
# (fl(dt,c('pseudotime'))+scale_color_gradientn(colors=scales::brewer_pal(palette = 'RdYlGn')(11) %>% rev)+ggtitle('Velocity Pseudotime'))|
(fl(dt,c('cytotrace'))+scale_color_gradientn(colors=scales::brewer_pal(palette = 'RdYlGn')(11) %>% rev)+ggtitle('1 - CytoTRACE'))
p&scale_x_continuous(n.breaks = 4)
rp()

ggsave('Figure/ArticleFigure/Figure4/4b-score.pdf',width=6,height=3)
ggsave('Figure/ArticleFigure/Figure4/4b-score.png',width=6,height=3)



dt=FindSubCluster(dt,3,'SCT_nn')

dt$veg=ifelse(dt$sub.cluster%in%c('3_1','3_3'),'VEC','nVEC') %>% fct_relevel(~.[c(2,1)])

DefaultAssay(dt)='SCT'

dt %<>% CellCycleScoring(
    s.features = Seurat::cc.genes.updated.2019$s.genes,
    g2m.features = Seurat::cc.genes.updated.2019$g2m.genes
)

sig = fread("~/lab/rec/stemness-index/pcbc-stemsig.tsv", header = F) %>% { sn(.$V2, .$V1) }# %>% sn(nm(.) %>% str_to_title)
data = dt@assays$SCT@data
genes = sec(rn(data), nm(sig))
data = data[genes, ] %>% as.matrix
sig = sig[genes]
plan(multicore, workers = 32)
sdx = future_map_dbl(1:ncol(data),~{
    cor(data[,.x],sig,method='sp')
})
# sdx = apply(data, 2, function(x) {
#     cor(sig, x, method = "sp")
# })
dt$stemidx=sdx

gs=fread('data_nmf/out3/GLDYS.txt')

DefaultAssay(dt)='SCT'

dt %<>% AddModuleScore(list(gs$GLDYS_M11),name='VEG')

dt$VEG.Score=dt$VEG1

a=FindMarkers(dt,c('3_1'),assay = 'gsvago',logfc.threshold = 0.1,only.pos = T,group.by = 'sub.cluster')
a

m=FindMarkers(dt,'VEC',assay='gsva',logfc.threshold = 0.1,only.pos = T,group.by = 'veg')



DefaultAssay(dt)='gsva'

a=c('GOBP-EXTRACELLULAR-MATRIX-DISASSEMBLY',
# 'HALLMARK-EPITHELIAL-MESENCHYMAL-TRANSITION',
'HALLMARK-P53-PATHWAY'#,'GOBP-KERATINIZATION'
   )

b=c('Extracellular Matrix\nDisassembly',
# 'Epithelial mesenchymal\ntransition',
'P53 Signaling\nPathway'#,'Keratinization'
   )

library(ggpubr)

gsva %<>% srn(rn(.) %>% str_replace_all('_','-'))

ps=map2(a,b,~data.frame(x=dt$ident1,y=gsva[.x,]) %>% filter(x%in%c('PMC','VEC')) %>% mutate(x=factor(x,levels=c('VEC','PMC'))) %>% 
        ggplot(aes(x=x,y=y,fill=x))+geom_violin()+theme_classic(20)+
        theme(plot.title = element_text(face = 'bold',hjust=0.5,size=20))+
        # ylim(c(-0.4,-0.4,-0.4,-0.5)[match(.x,a)],c(0.5,0.5,0.3,0.7)[match(.x,a)])+
        ylim(c(-0.4,-0.4,-0.4,-0.5)[match(.x,a)],c(0.5,0.3,0.7)[match(.x,a)])+
        xlab('')+ylab('GSVA score')+NoLegend()+ggtitle(.y)+geom_boxplot(width=0.1)+
        scale_fill_manual(values=c('#D62728','#FF7F0E'))+
     theme(axis.text = element_text(color='black',size=20))+stat_compare_means(comparisons = list(c('VEC','PMC')),size=8,label='p.signif',bracket.size = 0.8)
    ) %>% wrap_plots(ncol=1)

rp(4,8)
ps
rp()

ggsave('Figure/ArticleFigure/Figure4/4c.pdf',width=4,height = 8)
ggsave('Figure/ArticleFigure/Figure4/4c.png',width=4,height = 8)




