#!/usr/bin/env python
# coding: utf-8

# In[2]:


import sys, os, time, math, random
import matplotlib.pyplot as plt
from numpy import r_ as r
import numpy as np
import pandas as pd


# In[3]:


import scanpy as sc


# In[4]:


import anndata
# anndata.AnnData


# In[5]:


import scvelo as scv


# In[6]:


sam='HDYS4'


# In[7]:


# adata=anndata.read_loom('data/alevin.JC.loom')
adatawtf=scv.read(f'../_data/alevin.{sam}.G.3.h5ad')
# adatawtf=scv.read('data/alevin.IMS2.lowq.h5ad')


# In[8]:


adatawtf.layers['spliced']


# In[9]:


adatawtf.layers['unspliced']


# In[10]:


adata=adatawtf.copy()


# In[11]:


adata.obs['clusters']=adata.obs['seurat_clusters']


# In[ ]:





# # 

# In[12]:


scv.settings.verbosity = 3  # show errors(0), warnings(1), info(2), hints(3)
scv.settings.presenter_view = True  # set max width size for presenter view
# scv.set_figure_params('scvelo')  # for beautified visualization
scv.set_figure_params('scvelo',facecolor='white')  # for beautified visualization


# In[13]:


scv.utils.show_proportions(adata)


# In[14]:


scv.pl.proportions(adata)


# # 

# In[15]:


# scv.pp.filter_genes(adata, min_shared_counts = 30)
# scv.pp.normalize_per_cell(adata, enforce = True)
# scv.pp.filter_genes_dispersion(adata, n_top_genes = 2000)
# scv.pp.log1p(adata)
scv.pp.filter_and_normalize(adata, min_shared_counts=20, n_top_genes=2000,enforce=True)


# In[16]:


scv.pp.moments(adata, n_pcs=20, n_neighbors=20)


# In[ ]:





# In[ ]:





# # dynamic

# In[22]:


adata=adatawtf.copy()


# In[23]:


adata.obs['clusters']=adata.obs['seurat_clusters']


# In[24]:


# scv.pp.filter_genes(adata, min_shared_counts = 30)
# scv.pp.normalize_per_cell(adata, enforce = True)
# scv.pp.filter_genes_dispersion(adata, n_top_genes = 2000)
# scv.pp.log1p(adata)
scv.pp.filter_and_normalize(adata, min_shared_counts=20, n_top_genes=2000,enforce=True)


# In[25]:


# scv.pp.moments(adata, n_pcs=10, n_neighbors=10)
# scv.pp.moments(adata, n_pcs=20, n_neighbors=20)
# scv.pp.moments(adata, n_pcs=30, n_neighbors=20)
scv.pp.moments(adata, n_pcs=30, n_neighbors=30)


# In[26]:


scv.tl.recover_dynamics(adata,n_jobs=32,max_iter=20)


# In[ ]:





# In[27]:


scv.tl.velocity(adata, mode = 'dynamical')


# In[28]:


scv.tl.velocity_graph(adata)


# In[29]:


scv.pl.velocity_embedding_stream(adata, basis='umap',color='seurat_clusters')


# In[ ]:





# In[40]:


scv.pl.velocity_embedding_stream(adata, basis='umap',color='ident1',title='',legend_fontsize=18,figsize=[4,4],save='4b.png')


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




