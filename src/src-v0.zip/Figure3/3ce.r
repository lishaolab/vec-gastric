box::use(Seurat[...], patchwork[...], future[...], furrr[...], Matrix[...])
box::use(IRdisplay[d = display], data.table[fread], plyr[mpv = mapvalues])
box::use(magrittr[..., srn = set_rownames, scn = set_colnames], purrr[sn = set_names])
box::use(tibble[rn2c = rownames_to_column, c2rn = column_to_rownames], stringr[g = str_glue, s = str_c, ss = str_subset])
box::use(base[asdf = as.data.frame, asm = as.matrix, asl = as.list, asc = as.character, asi = as.integer, asd = as.double, asv = as.vector, len = length, nm = names, rn = rownames, cn = colnames, sec = intersect], utils[h = head])
options(max.print = 1000, repr.vector.max.items = 100, future.globals.maxSize = 1000 * 1024^4, future.rng.onMisuse = "ignore", datatable.fread.datatable = FALSE, box.path = '/data/egc21/lab')
RhpcBLASctl::blas_set_num_threads(16)
box::use(test/progressively[...])
plan(multicore, workers = 16)
library(tidyverse)
jlvi_brief = 1

if ("fs" %in% ls()) detach(fs) else fs = new.env()
fs$ata = . %>% as.data.frame %>% t %>% as.data.frame
fs$tb = function(x, ...) base::table(x, useNA = "ifany", ...)
fs$rp = function(w = 8, h = 6) options(repr.plot.width = w, repr.plot.height = h); fs$rp()
fs$ff = function(x, y, f = len) list(sec = f(sec(y, x)), union = f(union(y, x)), only_x = f(setdiff(x, y)), only_y = f(setdiff(y, x)))
fs$RotateAxis = function(angle = 45) theme(axis.text.x = element_text(angle = angle, hjust = ifelse(angle == 0, 0.5, 1), vjust = ifelse(angle == 90, 0.5, 1)))
fs$fwrite = function(x, ..., sep = "\t", row.names = has_rownames(x)) data.table::fwrite(x, ..., sep = sep, row.names = row.names)
fs$dl = function(dt, group.by = NULL, label = T, label.size = 6, shuffle = T, cells.highlight = NULL, raster = ncol(dt) > 20000, ...) suppressMessages(DimPlot(dt, group.by = group.by, label = label, label.size = label.size, shuffle = shuffle, cells.highlight = cells.highlight, raster = raster, ...))
fs$fl = function(dt, gs, order = T, raster = ncol(dt) > 20000, ncol = rep(1:4, c(1, 3, 5, 7))[len(gs)], ...) suppressMessages(FeaturePlot(dt, gs, order = order, ncol = ncol, raster = raster, ...))
fs$vl = function(dt, gs, group.by = NULL, pt.size = 0, ...) VlnPlot(dt, gs, group.by = group.by, pt.size = pt.size, ...)
fs$dtl = function(dt, gs, ...) DotPlot(dt, features = gs, ...) + RotateAxis()
fs$crl = function(corr, col = colorRampPalette(c("#67001F", "#B2182B", "#D6604D", "#F4A582", "#FDDBC7", "#FFFFFF", "#D1E5F0", "#92C5DE", "#4393C3", "#2166AC", "#053061") %>% rev)(200), ...) corrplot::corrplot(corr, col = col, ...)
fs$sl = . %>% unlist %>% sort %>% asl
attach(fs)

# sdf=fread('../table.name.211003.txt')
# sdf=fread('../table.name.211006.txt')
sdf=fread('table.name.211204.txt')

sdf

parts=c('GC', 'GIM', 'GLDYS', 'GNCAG', 'IIMLDYS') %>% sn

es = list()
vs = c('result.nmf',"Ws", "Hs", "Wmerge", "corr", "k", "hc", "corr2", "clusters", "Wmean", "gs",'Rmerge','Rmean') %>% sn



for (part in parts) {
    load(g("/home/zp14/Final_Results/Final_v1031/Section3/Figure3a_NMF_module/Final_NMF_modules/NMF_factors_features2000_{part}_update.Rdata"))
    Ws = map(result.nmf, ~.x@fit@W) %>% sn(nm(.) %>% str_remove("\\..*") %>% str_to_upper %>%
        mpv(c("AGC1", "AGC2", "HDYS1", "LDYS9_DYS", 'LDYS11_DYS'), c("AGC1_CAN", "AGC2_CAN", "HDYS1_CAN", "LDYS9", 'LDYS11'), F))
    Hs = map(result.nmf, ~.x@fit@H) %>% sn(nm(.) %>% str_remove("\\..*"))
    Wmerge = Ws %>% imap(~.x %>% asdf %>% scn(s(.y, ".", 1:ncol(.x))) %>% rn2c) %>% reduce(full_join, by = "rowname") %>% c2rn %>% replace(is.na(.), 0)
    # Hmerge= Hs %>% imap(~.x %>% ata %>% scn(s(.y, '.', 1:nrow(.x)))  %>% rn2c) %>% reduce(full_join, by = 'rowname') %>% c2rn #%>% .[, valid.factors]

    corr = Wmerge %>% asl %>% cross2(., .) %>% map_dbl(~{
        idx = (.x[[1]] > 1e-16) & (.x[[2]] > 1e-16)
        cor(.x[[1]][idx], .x[[2]][idx], method = "pe")
    }) %>% matrix(nrow = ncol(Wmerge), dimnames = cn(Wmerge) %>% list(., .))

    k = c(9, 6, 16, 5, 10)[match(part, parts)]
    hc = hclust(as.dist(1 - corr), method = "complete")
    corr2 = corr[hc$order, hc$order]
    clusters = hclust(as.dist(1 - corr2)) %>% cutree(k)

    if (part == "GLDYS") {
        clusters[which(clusters %in% c(6, 13))] <- 6
        # clusters[which(clusters %in% c(7, 8))] <- 7
        # clusters[which(clusters %in% c(15, 16))] <- 15
        clusters %<>% sort %>% mpv(unique(.), 1:(n_distinct(.)))
    }
    if (part == "IIMLDYS") {
        clusters[which(clusters %in% c(8, 10))] <- 8
        clusters %<>% sort %>% mpv(unique(.), 1:(n_distinct(.)))
    }
    if (part == "GC") {
        clusters[which(clusters %in% c(2, 3))] <- 2
        clusters %<>% sort %>% mpv(unique(.), 1:(n_distinct(.)))
    }
    
    corr2 %<>% .[nm(clusters), nm(clusters)]
    k = n_distinct(clusters)

    Wmean = map(1:k %>% sn, ~Wmerge[, nm(clusters)][, clusters == .x] %>% asdf %>% rowMeans) %>% asdf %>% asm
    gs = map(1:k, ~Wmean[, .x] %>% sort(T) %>% nm %>% .[1:100]) %>% asdf %>% scn(s("Module", 1:k))

    Rmerge = Wmerge %>% map_dfr(~base::rank(-., ties.method = "min")) %>% asdf %>% srn(rn(Wmerge))
    Rmean = Wmean %>% asdf %>% map_dfr(~base::rank(-., ties.method = "min")) %>% asdf %>% srn(rn(Wmean))

    es[[part]] = vs %>% map(get)
}

# es$GLDYS$gs %>% scn(s('M',1:ncol(.))) %>% fwrite('nmf/result/GLDYS.top100.txt')
es$GLDYS$gs %>% scn(s('M',1:ncol(.))) %>% fwrite('~/data_db/6.signature.v1.5/STAD.txt')



# imap(es,~.$gs %>% fwrite(g('result/{.y}.txt')))

# for (v in vs) assign(v, es$GLDYS[[v]])

W1=es$IIMLDYS$Rmerge[,es$IIMLDYS$clusters %>% .[.==8] %>% nm]
W2=es$GLDYS$Rmerge[,es$GLDYS$clusters %>% .[.==6] %>% nm]
W3=es$GLDYS$Rmerge[,es$GLDYS$clusters %>% .[.==5] %>% nm]
W4=es$GC$Rmerge[,es$GC$clusters %>% .[.==2] %>% nm]
W=list(W1,W2,W3,W4) %>% sn(c('MET_M2','GLDYS_M9','GLDYS_M10','GC_M7'))
W %<>% map(~{
    .x[.x<=50]=1
    .x[.x>50]=0
    a=rowSums(.x) %>% sort(T) %>% .[.>1]
    .x[a %>% nm,]
})

a1=es$IIMLDYS$gs$Module8[1:20]
a2=es$GLDYS$gs$Module6[1:20]
a3=es$GLDYS$gs$Module5[1:30]
a4=es$GC$gs$Module2[1:30]
a=c('KRT7','CEACAM6','CEACAM5',
    a1 %>% setdiff(tb(c(a1,a2)) %>% .[.>=2] %>% nm) %>% setdiff(c('KLK10','LAMC2')) %>% sec(W$MET_M2 %>% rn,.),
    tb(c(a1,a2)) %>% .[.>=2] %>% nm %>% setdiff(c('KLK10','LAMC2')),
    a2 %>% setdiff(tb(c(a2,a3)) %>% .[.>=2] %>% nm) %>% setdiff(c('KLK10','LAMC2')) %>% sec(W$GLDYS_M9 %>% rn,.),
    tb(c(a2,a3)) %>% .[.>=2] %>% nm %>% setdiff(c('KLK10','LAMC2')),
    a3 %>% setdiff(tb(c(a3,a4)) %>% .[.>=2] %>% nm) %>% setdiff(c('KLK10','LAMC2')) %>% sec(W$GLDYS_M10 %>% rn,.),
    tb(c(a3,a4)) %>% .[.>=2] %>% nm %>% c('KLK10','LAMC2',.),
    a4 %>% sec(W$GC_M7 %>% rn,.)
   ) %>% unique

# a=W %>% map(rn) %>% unlist %>% unique

W1=es$IIMLDYS$Rmerge[,es$IIMLDYS$clusters %>% .[.==8] %>% nm]
W2=es$GLDYS$Rmerge[,es$GLDYS$clusters %>% .[.==6] %>% nm]
W3=es$GLDYS$Rmerge[,es$GLDYS$clusters %>% .[.==5] %>% nm]
W4=es$GC$Rmerge[,es$GC$clusters %>% .[.==2] %>% nm]
W=list(W1,W2,W3,W4) %>% sn(c('MET_M2','GLDYS_M9','GLDYS_M10','GC_M7')) %>% imap(~.x %>% asdf  %>% rn2c) %>% 
    reduce(full_join, by = "rowname") %>% c2rn %>% replace(is.na(.), Inf) %>% .[sec(a,rn(.)),]
# W %<>% sweep(2,map_dbl(W,max),'/')
# W[W>100]=100
# W[W>50 & W<=75]=66
# W[W>25 & W<=50]=33
# W[W<=25]=0
W[W>50]=50
W[W>25 & W<50]=30
W[W<=25]=0
W[W==0]='Top 25'
W[W==30]='Top 50'
W[W==50]=''

df=W %>% .[rn(.) %>% rev,] %>% asm %>% as.table %>% asdf #%>% mutate(Var2=Var2 %>%  str_remove('\\.\\d') %>% mpv(sdf$sample,sdf$sam,F))


widths=c(ncol(W1),ncol(W2),ncol(W3),ncol(W4))

sams=c('MET-M2','G-LGD-M9','G-LGD-M10','GC-M7') %>% rep(widths)

# colors=scales::brewer_pal('qual',2)(3) %>% sn(c('IIM','VEG','GC')) %>% .[sams]
# colors2=scales::brewer_pal('qual',3)(4) %>% sn(c('IIM','VEG','GC')) %>% .[sams]

# sdf=fread('table.name.211003.txt')
sdf=fread('table.name.211204.txt')

a=c(cn(W1),cn(W2),cn(W3),cn(W4)) %>% str_remove('\\..*') %>% mpv('AGC5_CAN','AGC2_LDYS') %>% mpv(sdf$sample, sdf$group, F)  %>% mpv('AGC2_LDYS','LGD_GC') #%>% str_remove('^.*_')

a %<>% replace(str_starts(.,'CCR'),'AGC')

colors=scales::brewer_pal(palette = 'Set3')(n_distinct(a)) %>% sn(unique(a)) %>% .[a]

# color.index  %T>% scales::show_col()

colors=color.index[-1] %>% sn(c('IM_Per','IM_Pro','IM_GC','LGD_Reg','LGD_Per','LGD_Pro','LGD_GC','EGC','AGC')) %>% .[a]

df1 = data.frame(a = a %>% unique, b = colors %>% unique) %>% .[-3,]
p01 = ggplot(df1, aes(x = a, fill = a)) + geom_bar() + scale_fill_manual(values = sn(df1$b,df1$a), name = "Outcome",breaks=c('IM_Per','IM_Pro','IM_GC','LGD_Reg','LGD_Per','LGD_Pro','LGD_GC','EGC','AGC')) + theme_void()

library(ggrepel)

df$label=''
df[df$Var1=='KRT7'&df$Var2=='IMW3.8','label']='KRT7'
df[df$Var1=='CEACAM5'&df$Var2=='IMW3.8','label']='CEACAM5'
df[df$Var1=='CEACAM6'&df$Var2=='IMW3.8','label']='CEACAM6'
df[df$Var1=='KLK10'&df$Var2=='IMW3.8','label']='KLK10'
df[df$Var1=='LAMC2'&df$Var2=='IMW3.8','label']='LAMC2'
df[df$Var1=='CDA'&df$Var2=='IMW3.8','label']='CDA'
df[df$Var1=='LGALS1'&df$Var2=='IMW3.8','label']='LGALS1'
df[df$Var1=='KRT17'&df$Var2=='IMW3.8','label']='KRT17'



rp(7, 10)
p1=ggplot(df, aes(x = Var2, y = Var1, fill = Freq,label=label)) +
    geom_tile() +
    # geom_tile(color='black') +
    # theme_minimal(base_family = 'Arial') +
    theme_minimal() +
    theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
    theme(axis.text = element_text(color = 'black')) +
    RotateAxis(90) +
    scale_fill_manual(values = c('grey', 'black', 'white') %>% rev) +
    # scale_x_discrete(labels = . %>% str_remove('\\.\\d') %>% mpv(sdf$sample, sdf$sam, F)) +
    # scale_x_discrete(labels = . %>% str_remove('\\..*') %>% mpv(sdf$sample, sdf$sam, F) %>% mpv('AGC2','AGC2_LDYS')) +
    annotate("rect", xmin = 0.5, xmax = ncol(W) + 0.5, ymin = 0.5, ymax = nrow(W) + 0.5, color = 'black', fill = '#FFFFFF00') + # kuang
    annotate('rect', xmin=c(0,widths %>% cumsum) %>% head(-1)+0.75 ,xmax=widths %>% cumsum+0.25, ymin = -1.4, fill = 'black', ymax=-1.6) + # hp
    # annotate('rect', xmin=0 ,xmax=51, ymin = 12, fill = 'white', ymax=16) + # hp
    annotate('text', label = c('MET-M2','G-LGD-M9','G-LGD-M10','GC-M7'), x = widths %>% cumsum %>% c(0,.) %>% caTools::runmean(k = 2) %>% tail(-1)+1, 
             y = -2.3, hjust = 1, vjust = 0.5,angle=45,size=5) +
    # annotate('tile', x = 1:len(a), y = 0.2, fill = colors, height = 0.4) + # outcome
    annotate('tile', x = 1:len(a), y = -0.5, fill = colors, height = 1) + # outcome

    # annotate('line',x=c(2,3,4),y=c(10,20,30))+
    # theme(plot.margin = unit(c(0.5, 0.5, 2, 0.5), units = 'cm')) +
    xlab('') +
    ylab('') +
    theme(plot.margin=margin(0,0,60,70)) +
    theme(axis.text.x = element_blank()) +
    # theme(axis.text.y = element_blank()) +
    # geom_text_repel(direction = "y",force=1.5, hjust= 1,nudge_x = -13,size=5, xlim=c(-13,100))+
    labs(fill = '') +
    # coord_cartesian(ylim=c(0,nrow(W)),clip = 'off')
    coord_cartesian(ylim = c(1, nrow(W)), clip = 'off')
rp()

rp(7,10)
p = (p01 | p1) + plot_layout(widths = c(0, 1), guides = 'collect') & theme(legend.position = 'right')
p  &  theme(legend.title = element_text(size=16))&
    theme(legend.text = element_text(size=12))
rp()



ggsave('Figure/ArticleFigure/Figure3/3c.pdf',width=7,height=10)
ggsave('Figure/ArticleFigure/Figure3/3c.png',width=7,height=10)



Ws=list(es$GLDYS$Ws %>% sn(nm(.) %>% mpv('AGC5_CAN','AGC2_LGD')), es$GC$Ws)
Ws %<>% unlist(recursive = F)
Wmerge = Ws %>% imap(~.x %>% asdf %>% scn(s(.y, ".", 1:ncol(.x))) %>% rn2c) %>% reduce(full_join, by = "rowname") %>% c2rn %>% replace(is.na(.), 0)
# Hmerge= Hs %>% imap(~.x %>% ata %>% scn(s(.y, '.', 1:nrow(.x)))  %>% rn2c) %>% reduce(full_join, by = 'rowname') %>% c2rn #%>% .[, valid.factors]

corr = Wmerge %>% asl %>% cross2(., .) %>% map_dbl(~{
    idx = (.x[[1]] > 1e-16) & (.x[[2]] > 1e-16)
    cor(.x[[1]][idx], .x[[2]][idx], method = "pe")
}) %>% matrix(nrow = ncol(Wmerge), dimnames = cn(Wmerge) %>% list(., .))

k = 12
hc = hclust(as.dist(1 - corr), method = "complete")
corr2 = corr[hc$order, hc$order]
clusters = hclust(as.dist(1 - corr2)) %>% cutree(k)

corr2 %<>% .[nm(clusters), nm(clusters)]
k = n_distinct(clusters)

Wmean = map(1:k %>% sn, ~Wmerge[, nm(clusters)][, clusters == .x] %>% asdf %>% rowMeans) %>% asdf %>% asm
gs = map(1:k, ~Wmean[, .x] %>% sort(T) %>% nm %>% .[1:50]) %>% asdf %>% scn(s("Module", 1:k))

Rmerge = Wmerge %>% map_dfr(~base::rank(-., ties.method = "min")) %>% asdf %>% srn(rn(Wmerge))
Rmean = Wmean %>% asdf %>% map_dfr(~base::rank(-., ties.method = "min")) %>% asdf %>% srn(rn(Wmean))

part='GLDYSGC'
idx=6



idx=5

idx=idx+1
idx

part=parts[3] %T>% d
idx=match(part,parts)
for (v in vs) assign(v, es[[part]][[v]])



# gs %>% asl %>% cross2(.,.) %>% map_int(~len(sec(.[[1]],.[[2]]))) %>% matrix(nrow=ncol(gs)) %>% asdf %>% srn(cn(.))
# gs %>% map_df(~{ a=.x; map_df(gs,~len(sec(a,.x))) }) %>% asdf %>% srn(cn(.))

# clusters %<>% replace(.==3,2)
# clusters[clusters>3]=clusters[clusters>3]-1
# # clusters %<>% replace(.==6,13)
# # clusters %<>% replace(.==14,13)
# # clusters[clusters>6]=clusters[clusters>6]-1
# # clusters[clusters>14]=clusters[clusters>14]-2
# clusters %<>% sort
# corr2 %<>% .[nm(clusters),nm(clusters)]

# a = clusters %>% tb %>% .[. > 3] %>% nm %>% asi
a = clusters %>% tb %>% .[. > 3] %>% nm %>% asi
# if (part == "GC") a %<>% c(12) %>% sort
# if (part == "GIM") a %<>% c(3) %>% sort
# if (part == "NCAG") a %<>% c(5,7,8) %>% sort
dfa = clusters %>% tb %>% cumsum %>% add(0.5) %>% asl %>% ata %>% mutate(V0 = c(0.5, V1 %>% .[-len(.)]), .before = 1) %>% 
    rowid_to_column("id0") %>% .[a, ] %>% rowid_to_column %>% mutate(alpha = ifelse(rowid%%2, 1, 0.5)) %>% 
    mutate(gene = gs[, a] %>% imap_chr(~.[1:5] %>% s(collapse = ' '))) %>% 
    # mutate(annot=c('GC','GIM','GLDYS','N/CAG','MET') %>% sn(parts) %>% .[part] %>% s('_M',rowid,'\n',gene)) %T>% d
    mutate(annot=c('GC','G-IM','G-LGD','G-N/CAG','MET','G-LGD+GC')[idx] %>% s('-M',rowid) %>% rev) %T>% d
    # mutate(annot=s('Module',rowid)) %T>% d

N=nrow(corr2)
colors = scales::brewer_pal(type = 'seq', palette = 1, direction = 1)(9) %>% c('#FFFFFF', .) # %>% {colorRampPalette(.)(92)}
# facs = rn(corr2) %>% str_remove("\\.[\\d]+")
# facs = rn(corr2) %>% str_remove('[_]*\\d.*')
facs =rn(corr2) %>% str_remove('\\..*') %>% mpv(sdf$sample,sdf$sam,F)
facs2=rn(corr2) %>% str_remove('\\..*') %>% mpv(sdf$sample,sdf$group,F) %>% replace_na('NA') %>% replace(str_starts(.,'CCR'),'AGC')
facs3=rn(corr2) %>% str_remove('\\..*') %>% mpv(sdf$sample,sdf$hp,F) %>% replace_na('NA')# %>% replace(.=='','blank')


if (part=='GLDYSGC'){
    facs2 %<>% mpv('AGC2_LGD','LGD_GC')
}
if (part=='GLDYS'){
    facs %<>% mpv('AGC2','AGC2_LGD')
    facs2 %<>% mpv('AGC','LGD_GC')
}

colors_all=scales::brewer_pal(palette='Set3')(12) %>% c(scales::brewer_pal(palette = 'Set1')(9)) %>% sort
if (part=='IIMLDYS'|part=='GLDYSGC') colors_all %<>% c(scales::brewer_pal(palette = 'Set2')(8)) %>% sort
colors_facs=colors_all[1:n_distinct(facs)] %>% set_names(facs %>% unique) %>% .[facs]

colors_facs2=scales::brewer_pal(palette='Set2')(n_distinct(facs2)) %>% set_names(facs2 %>% unique) %>% .[facs2]
if (part=='IIMLDYS') colors_facs2=scales::brewer_pal(palette='Set2')(8) %>% c(scales::brewer_pal(palette = 'Set1')(n_distinct(facs2)-8)) %>% set_names(facs2 %>% unique) %>% .[facs2]
# colors_facs3=scales::brewer_pal(palette='Set1')(n_distinct(facs3)) %>% set_names(facs3 %>% unique) %>% .[facs3]
colors_facs3=c(P='#E41A1C',N='#377EB8') %>% .[facs3]

df1 = data.frame(a = facs %>% unique, b = colors_facs %>% unique)
p01 = ggplot(df1, aes(x = a, fill = a)) + geom_bar() + scale_fill_manual(values = sn(df1$b,df1$a), name = "Sample") + theme_void(16)

df2 = data.frame(a = facs2 %>% unique, b = colors_facs2 %>% unique)
p02 = ggplot(df2, aes(x = a, fill = a)) + geom_bar() + scale_fill_manual(values = sn(df2$b,df2$a), name = "Group") + theme_void(16)

if (part!='GC'){
    df3 = data.frame(a = facs3 %>% unique, b = colors_facs3 %>% unique) %>% arrange(desc(a))
    p03 = ggplot(df3, aes(x = a, fill = a)) + geom_bar() + scale_fill_manual(values = sn(df3$b,df3$a), name = "Hp infection") + theme_void(16)
}

df = corr2 %>% unname %>% reshape2::melt()
df$value %<>% pmax(-0.0)
p1 = ggplot(df, aes(x = Var1, y = Var2, fill = value)) + geom_tile() +
    xlab('Factors') + ylab('Factors') +
    scale_fill_gradientn(colors = colors, name = 'Correlation', limits = c(-0.0, 1)) +
    scale_x_continuous(expand = c(0, 0), breaks = seq(20, N, 20)) +
    scale_y_continuous(expand = c(0, 0), breaks = seq(20, N, 20)) +
    theme_minimal(16,base_family = 'Arial') +
    theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
    theme(plot.margin = unit(c(0, 3.5, 0, 0), units = 'cm')) +
    theme(axis.title = element_text(size = 18), axis.text = element_text(size = 16)) +
    annotate("rect", xmin = 0.5, xmax = N + 0.5, ymin = 0.5, ymax = N + 0.5, color = 'black', fill = '#FFFFFF00') + # kuang
    annotate('rect', xmin = dfa$V0, xmax = dfa$V1, ymin = dfa$V0, ymax = dfa$V1, color = 'black', fill = '#FFFFFF00') + # module kuang
    coord_fixed(clip = 'off') #+scale_y_reverse()




if (part!='GLDYS') {} else{
p=p1+annotate('tile', x = 1:N, y = N-1 + 6, fill = colors_facs, height = 3) + # sample
     annotate('tile', x = 1:N, y = N-1 + 10, fill = colors_facs2, height = 3) + # outcome
     annotate('tile', x = 1:N, y = N-1 + 14, fill = colors_facs3, height = 3) + # hp
     annotate('rect', xmin = N + 2.5, xmax = N + 3.5, ymin = dfa$V0 + 0.5, ymax = dfa$V1 - 0.5, alpha = dfa$alpha) + # bar
     annotate('text', label = dfa$annot, x = N + 5, y = (dfa$V0 + dfa$V1) / 2, hjust = 0, vjust = 0.5, size = 5)  # text
rp(10, 10)
p = (p03 | p02 | p01 | p) + plot_layout(widths = c(0,0,0, 1), guides = 'collect') & theme(legend.position = 'left')
p
rp()
}

if (part!='IIMLDYS') {} else{
p=p1+annotate('tile', x = 1:N, y = N-1 + 6, fill = colors_facs, height = 3) + # sample
     annotate('tile', x = 1:N, y = N-1 + 10, fill = colors_facs2, height = 3) + # outcome
     annotate('tile', x = 1:N, y = N-1 + 14, fill = colors_facs3, height = 3) + # hp
     annotate('rect', xmin = N + 2.5, xmax = N + 3.5, ymin = dfa$V0 + 0.5, ymax = dfa$V1 - 0.5, alpha = dfa$alpha) + # bar
     annotate('text', label = dfa$annot, x = N + 5, y = (dfa$V0 + dfa$V1) / 2, hjust = 0, vjust = 0.5, size = 5)  # text
rp(10, 11)
p = (p03 | p02 | p01 | p) + plot_layout(widths = c(0,0,0, 1), guides = 'collect') & theme(legend.position = 'left')
p
rp()
}



if (part!='GIM')  {} else{
p=p1+annotate('tile', x = 1:N, y = N-3 + 6, fill = colors_facs, height = 2) + # sample
     annotate('tile', x = 1:N, y = N-3 + 9, fill = colors_facs2, height = 2) + # outcome
     annotate('tile', x = 1:N, y = N-3 + 12, fill = colors_facs3, height = 2) + # hp
     annotate('rect', xmin = N + 1.5, xmax = N + 2, ymin = dfa$V0 + 0.5, ymax = dfa$V1 - 0.5, alpha = dfa$alpha) + # bar
     annotate('text', label = dfa$annot, x = N + 3, y = (dfa$V0 + dfa$V1) / 2, hjust = 0, vjust = 0.5, size = 5)  # text
rp(10, 10)
p = (p03 | p02 | p01 | p) + plot_layout(widths = c(0,0,0, 1), guides = 'collect') & theme(legend.position = 'left')
p
rp()
}

if (part!='GC')  {} else{
p=p1+annotate('tile', x = 1:N, y = N-3 + 6, fill = colors_facs, height = 2) + # sample
     annotate('tile', x = 1:N, y = N-3 + 9, fill = colors_facs2, height = 2) + # outcome
     annotate('rect', xmin = N-1 + 2.5, xmax = N-1 + 3, ymin = dfa$V0 + 0.5, ymax = dfa$V1 - 0.5, alpha = dfa$alpha) + # bar
     annotate('text', label = dfa$annot, x = N + 3, y = (dfa$V0 + dfa$V1) / 2, hjust = 0, vjust = 0.5, size = 5)  # text
rp(10, 10)
p = (p02 | p01 | p) + plot_layout(widths = c(0,0, 1), guides = 'collect') & theme(legend.position = 'left')
p
rp()
}

if (part!='GNCAG')  {} else{
p=p1+annotate('tile', x = 1:N, y = N-3 + 6, fill = colors_facs, height = 2) + # sample
     # annotate('tile', x = 1:N, y = N-3 + 9, fill = colors_facs2, height = 2) + # outcome
     annotate('rect', xmin = N-1 + 2.4, xmax = N-1 + 2.8, ymin = dfa$V0 + 0.5, ymax = dfa$V1 - 0.5, alpha = dfa$alpha) + # bar
     annotate('text', label = dfa$annot, x = N + 2.5, y = (dfa$V0 + dfa$V1) / 2, hjust = 0, vjust = 0.5, size = 5)  # text
rp(10, 10)
p = (p01 | p) + plot_layout(widths = c(0, 1), guides = 'collect') & theme(legend.position = 'left')
p
rp()
}

if (part!='GLDYSGC')  {} else{
p=p1+annotate('tile', x = 1:N, y = N-1 + 6, fill = colors_facs, height = 3) + # sample
     annotate('tile', x = 1:N, y = N-1 + 10, fill = colors_facs2, height = 3) + # outcome
     # annotate('tile', x = 1:N, y = N-1 + 14, fill = colors_facs3, height = 3) + # hp
     annotate('rect', xmin = N + 2.5, xmax = N + 3.5, ymin = dfa$V0 + 0.5, ymax = dfa$V1 - 0.5, alpha = dfa$alpha) + # bar
     annotate('text', label = dfa$annot, x = N + 5, y = (dfa$V0 + dfa$V1) / 2, hjust = 0, vjust = 0.5, size = 5)  # text
rp(10, 10)
p = (p02 | p01 | p) + plot_layout(widths = c(0,0, 1), guides = 'collect') & theme(legend.position = 'left')
p
rp()
}



# ggsave(g('plot/{part}.png'),p,width = 10,height = 11,units = 'in')
ggsave(g('plot/{part}.png'),p,width = 10,height = ifelse(idx==5, 11,10),units = 'in')

db.ms.CGP = msigdbr::msigdbr(species = "Homo sapiens", subcategory = 'CGP') %>% select(gs_name, gene_symbol) %>% group_by(gs_name) %>% summarise(gene_symbol=list(gene_symbol))
# enrich=a$`8.JiZaoQi-2` %>% clusterProfiler::enricher(TERM2GENE = db.ms.CGP, minGSSize = 1) %>% asdf %>% .[,-c(1,2)]
# a$`8.JiZaoQi-2` %>% clusterProfiler::enricher(TERM2GENE = wtf, minGSSize = 1) %>% asdf %>% .[,-c(1,2)]

# a=es$GLDYS$Wmean[,5] %>% sort(T) %>% scale(T,F) %>% asdf %>% rn2c %>% deframe
# a=es$GLDYS$Wmean[,5] %>% sort(T) %>% subtract(median(.)) %>% asdf %>% rn2c %>% deframe
a=es$GLDYS$Wmean[,5] %>% sort(T) %>% subtract(mean(.)) %>% asdf %>% rn2c %>% deframe

# gseas=es$GLDYS$Wmean[,5] %>% sort(T) %>% subtract(mean(.)) %>% clusterProfiler::GSEA(TERM2GENE = db.ms.CGP)
gseas=a %>% clusterProfiler::GSEA(TERM2GENE = db.ms.CGP)

rp(6, 4)
p1 = enrichplot::gseaplot2(gseas, geneSetID = "VECCHI_GASTRIC_CANCER_EARLY_UP", title = "VECCHI_GASTRIC_CANCER_EARLY_UP", 
    subplots = 1, pvalue_table = F)
p2 = enrichplot::gseaplot2(gseas, geneSetID = "VECCHI_GASTRIC_CANCER_EARLY_UP", title = "VECCHI_GASTRIC_CANCER_EARLY_UP", 
    subplots = 2, pvalue_table = F)
# +annotate('text',x=500,y=0.1,label='123')
p1 = p1 + xlab(NULL) + ylab('Enrichment Score (ES)') + 
    annotate("text", x = 1800, y = 0.3+0.12, size = 6, hjust=0,vjust=0,label = g("NES = {format(gseas@result['VECCHI_GASTRIC_CANCER_EARLY_UP','NES'],scientific=F,digits=3)}")) + 
    annotate("text", x = 1800, y = 0.3+0.06, size = 6,hjust=0,vjust=0, label = g("p = {format(gseas@result['VECCHI_GASTRIC_CANCER_EARLY_UP','pvalue'],scientific=T,digits=3)}")) + 
    annotate("text", x = 1800, y = 0.3+0, size = 6,hjust=0,vjust=0, label = g("q = {format(gseas@result['VECCHI_GASTRIC_CANCER_EARLY_UP','qvalues'],scientific=T,digits=3)}")) + 
    theme_bw(16) + theme(legend.position = "none", plot.margin = margin(t = -0.1, b = -2, unit = "cm"), 
    axis.ticks.x = element_blank(), axis.text.x = element_blank(), axis.line.x = element_blank())+
    theme(axis.text = element_text(color='black',size=16))+
    theme(axis.title = element_text(color='black',size=18))
p2 = p2 + theme(axis.text.x = element_blank(), axis.ticks.x = element_blank())
p=p1/p2 + plot_layout(heights = c(3, 1))
p
# xlim(c(0,100))
rp()



ggsave(g('Figure/ArticleFigure/Figure3/3e.pdf'),p,width = 6,height = 4)
ggsave(g('Figure/ArticleFigure/Figure3/3e.png'),p,width = 6,height = 4)






