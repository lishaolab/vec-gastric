box::use(Seurat[...], patchwork[...], future[...], furrr[...], Matrix[...])
box::use(IRdisplay[d = display], data.table[fread], plyr[mpv = mapvalues])
box::use(magrittr[..., srn = set_rownames, scn = set_colnames], purrr[sn = set_names])
box::use(tibble[rn2c = rownames_to_column, c2rn = column_to_rownames], stringr[g = str_glue, s = str_c, ss = str_subset])
box::use(base[asdf = as.data.frame, asm = as.matrix, asl = as.list, asc = as.character, asi = as.integer, asd = as.double, asv = as.vector, len = length, nm = names, rn = rownames, cn = colnames, sec = intersect], utils[h = head])
options(max.print = 1000, repr.vector.max.items = 100, future.globals.maxSize = 1000 * 1024^4, future.rng.onMisuse = "ignore", datatable.fread.datatable = FALSE, box.path = '/data/egc21/lab')
RhpcBLASctl::blas_set_num_threads(16)
box::use(test/progressively[...])
plan(multicore, workers = 16)
library(tidyverse)
jlvi_brief = 1

if ("fs" %in% ls()) detach(fs) else fs = new.env()
fs$ata = . %>% as.data.frame %>% t %>% as.data.frame
fs$tb = function(x, ...) base::table(x, useNA = "ifany", ...)
fs$rp = function(w = 8, h = 6) options(repr.plot.width = w, repr.plot.height = h); fs$rp()
fs$ff = function(x, y, f = len) list(sec = f(sec(y, x)), union = f(union(y, x)), only_x = f(setdiff(x, y)), only_y = f(setdiff(y, x)))
fs$RotateAxis = function(angle = 45) theme(axis.text.x = element_text(angle = angle, hjust = ifelse(angle == 0, 0.5, 1), vjust = ifelse(angle == 90, 0.5, 1)))
fs$fwrite = function(x, ..., sep = "\t", row.names = has_rownames(x)) data.table::fwrite(x, ..., sep = sep, row.names = row.names)
fs$dl = function(dt, group.by = NULL, label = T, label.size = 6, shuffle = T, cells.highlight = NULL, raster = ncol(dt) > 20000, ...) suppressMessages(DimPlot(dt, group.by = group.by, label = label, label.size = label.size, shuffle = shuffle, cells.highlight = cells.highlight, raster = raster, ...))
fs$fl = function(dt, gs, order = T, raster = ncol(dt) > 20000, ncol = rep(1:4, c(1, 3, 5, 7))[len(gs)], ...) suppressMessages(FeaturePlot(dt, gs, order = order, ncol = ncol, raster = raster, ...))
fs$vl = function(dt, gs, group.by = NULL, pt.size = 0, ...) VlnPlot(dt, gs, group.by = group.by, pt.size = pt.size, ...)
fs$dtl = function(dt, gs, ...) DotPlot(dt, features = gs, ...) + RotateAxis()
fs$crl = function(corr, col = colorRampPalette(c("#67001F", "#B2182B", "#D6604D", "#F4A582", "#FDDBC7", "#FFFFFF", "#D1E5F0", "#92C5DE", "#4393C3", "#2166AC", "#053061") %>% rev)(200), ...) corrplot::corrplot(corr, col = col, ...)
fs$sl = . %>% unlist %>% sort %>% asl
attach(fs)

part = "GLDYS"
load(g("/home/zp14/Final_Results/Final_v1031/Section3/Figure3a_NMF_module/Final_NMF_modules/NMF_factors_features2000_{part}.Rdata"))
Ws = map(result.nmf, ~.x@fit@W)
Hs = map(result.nmf, ~.x@fit@H)
sams = Ws %>% nm
n = len(sams)

# valid.factors = map(Hs %>% unname, ~apply(.x, 1, sd)) %>% unlist %>% sort(decreasing = T) %>% .[1:round(length(.) * 0.85)] %>% names
Wmerge = Ws %>% imap(~.x %>% asdf %>% scn(s(.y, ".", 1:ncol(.x))) %>% rn2c) %>% reduce(full_join, by = "rowname") %>% c2rn  #%>% .[, valid.factors]
Wmerge[is.na(Wmerge)] = 0
corr = map_dfr(as.list(Wmerge), ~{
    i = .x
    map_dbl(as.list(Wmerge), ~{
        j = .x
        idx = (i > 1e-16) & (j > 1e-16)
        cor(i[idx], j[idx], method = "pe")
    })
}) %>% as.matrix %>% srn(cn(.))
# Hmerge= Hs %>% map(~.x %>% t %>% asdf %>% r2c) %>% reduce(full_join, by = 'rowname') %>% c2r #%>% .[, valid.factors]

k = 16
hc = hclust(as.dist(1 - corr),method = 'complete')
corr2 = corr[hc$order, hc$order]
clusters = hclust(as.dist(1 - corr2)) %>% cutree(k)
Wmean = map(1:k %>% sn, ~Wmerge[, hc$order][, clusters == .x] %>% asdf %>% rowMeans) %>% asdf %>% as.matrix

# map(1:k,~Wmean[,.x] %>% sort(decreasing = T) %>% names %>% {which(.=='KLK10')})
# genes=c('KLK10','KRT7','LAMC2','TNFAIP2','UBD','IL32','MMP7','CEACAM5','PSCA','NFKBIA','TNFAIP3','ITGA2','IL8')
genes=c('KLK10','KRT7','LAMC2','TNFAIP2','UBD','IL32','MMP7','MMP1','CEACAM5','PSCA','NFKBIA','TNFAIP8','ITGA2','ETS2','SOX4','HES4','MUC5AC','TACSTD2')

# rp(16,16)
# col <- colorRampPalette(c("#67001F", "#B2182B", "#D6604D", "#F4A582", "#FDDBC7", "#FFFFFF", "#D1E5F0", "#92C5DE", "#4393C3", "#2166AC", "#053061") %>% rev)
# # a=corrplot::corrplot(corr, order = "hclust", addrect = k, tl.pos = "n", col = col(200),hclust.method='complete')
# a=corrplot::corrplot(corr, order = "hclust", addrect = k, col = col(200),hclust.method='complete')
# rp()

genes100 = map(1:k, ~Wmean[, .x] %>% sort(decreasing = T) %>% names %>% .[1:100]) %>% 
    asdf %>% scn(s('Module',1:k)) %T>% d #%T>% fwrite(g('data_nmf/out2/{part}.txt'))



# load('/home/zp14/Final_Results/Final_v1031/Section3/Figure3a_NMF_module/Final_NMF_modules/final.result.merge.GLDYS.update.Rdata')
load('/home/zp14/Final_Results/Final_v1031/Section3/Figure3a_NMF_module/Final_NMF_modules/final.result.merge.GIM.update.Rdata')

dts=final.result.merge.GIM %>% imap(~CreateSeuratObject(.x@assays$RNA@counts,meta.data = .x@meta.data) %>% {.$sample=.y;.}) 

# dts$IMS2=NULL
# dts$AGC8=NULL
# dts$HDYS2=NULL

dt2 = merge(dts[[1]],dts[-1])

dt2$sample %>% tb

# dt %<>% NormalizeData %>% FindVariableFeatures %>% ScaleData %>% RunPCA(verbose = F) %>% FindNeighbors %>% FindClusters %>% RunUMAP(dims=1:20)
dt2 %<>% NormalizeData %>% FindVariableFeatures %>% ScaleData %>% RunPCA %>% FindNeighbors(dims=1:20) %>% FindClusters %>% RunUMAP(dims=1:20)

gs=fread('nmf/result/GC.txt')

dt %<>% AddModuleScore(list(gs$GC_M7),name='GC.Score')

gs=fread('nmf/result/GLDYS.txt')

dt %<>% AddModuleScore(list(gs$GLDYS_M10),name='VEC.Score')

# e=future(saveRDS(dt,'data/dt.merge.GLDYS.211110.rds'))

dt=readRDS('nmf/data/dt.merge.GLDYS.211110.rds')

# a=readLines('../data.sync/geneset.egc.txt')
# o2n = fread("~/lab/data.sync/o2n.hg19.txt") %>% { function(x) mpv(x, .[[1]], .[[2]], F) }
# # dt %<>% AddModuleScore(list(o2n(a)),name='EGC.Score')



gs=fread('nmf/result/GC.txt')

dt %<>% AddModuleScore(list(gs$GC_M7),name='GC.Score')

gs=fread('nmf/result/GLDYS.txt')

dt %<>% AddModuleScore(list(gs$GLDYS_M10),name='VEC.Score')



dt %<>% AddModuleScore(list(c('KLK10','LAMC2')))

# sdf=fread('table.name.211003.txt')
sdf=fread('table.name.211204.txt')

dt$sam=dt$sample %>% mpv(sdf$sample,sdf$sam) %>% mpv('AGC2','AGC2_LGD')



rp(15,5)
# (dl(dt,'sam',F,pt.size=2)+ggtitle('')+scale_color_manual(values=colors))|
p=(dl(dt,'sam',F,pt.size=2)+ggtitle(''))|
(fl(dt,'VEC.Score1',max.cutoff=1.2,pt.size=4)+ggtitle('VEC Score')+scale_color_gradientn(colors=scales::brewer_pal(palette = 'RdYlGn')(11) %>% rev))|
# (fl(dt,'Cluster1',max.cutoff=1.2,pt.size=4)+ggtitle('VEC Score 2')+scale_color_gradientn(colors=scales::brewer_pal(palette = 'RdYlGn')(11) %>% rev))|
(fl(dt,'GC.Score1',pt.size=4)+ggtitle('EGC Score')+scale_color_gradientn(colors=scales::brewer_pal(palette = 'RdYlGn')(11) %>% rev))
p & theme(
    plot.title=element_text(size=20),
    legend.text = element_text(size = 16),
                 # legend.position = 'right',
                 # legend.key.height = unit(1.4,"cm"),
                 # legend.key.width = unit(1.4,"cm"),
                 axis.text.x = element_text(size = 16),
                 axis.text.y = element_text(size = 16),
                 axis.title.x = element_text(size = 16),
                 axis.title.y = element_text(size = 16))
rp()
# ggsave('Figure/ArticleFigure/Figure3/3d.pdf',width=15,height=5)
# ggsave('Figure/ArticleFigure/Figure3/3d.png',width=15,height=5)






