box::use(Seurat[...], patchwork[...], future[...], furrr[...], Matrix[...])
box::use(IRdisplay[d = display], data.table[fread], plyr[mpv = mapvalues])
box::use(magrittr[..., srn = set_rownames, scn = set_colnames], purrr[sn = set_names])
box::use(tibble[rn2c = rownames_to_column, c2rn = column_to_rownames], stringr[g = str_glue, s = str_c, ss = str_subset])
box::use(base[asdf = as.data.frame, asm = as.matrix, asl = as.list, asc = as.character, asi = as.integer, asd = as.double, asv = as.vector, len = length, nm = names, rn = rownames, cn = colnames, sec = intersect], utils[h = head])
options(max.print = 1000, repr.vector.max.items = 100, future.globals.maxSize = 1000 * 1024^4, future.rng.onMisuse = "ignore", datatable.fread.datatable = FALSE, box.path = '/data/egc21/lab')
RhpcBLASctl::blas_set_num_threads(16)
box::use(test/progressively[...])
plan(multicore, workers = 16)
library(tidyverse)
jlvi_brief = 1

if ("fs" %in% ls()) detach(fs) else fs = new.env()
fs$ata = . %>% as.data.frame %>% t %>% as.data.frame
fs$tb = function(x, ...) base::table(x, useNA = "ifany", ...)
fs$rp = function(w = 8, h = 6) options(repr.plot.width = w, repr.plot.height = h); fs$rp()
fs$ff = function(x, y, f = len) list(sec = f(sec(y, x)), union = f(union(y, x)), only_x = f(setdiff(x, y)), only_y = f(setdiff(y, x)))
fs$RotateAxis = function(angle = 45) theme(axis.text.x = element_text(angle = angle, hjust = ifelse(angle == 0, 0.5, 1), vjust = ifelse(angle == 90, 0.5, 1)))
fs$fwrite = function(x, ..., sep = "\t", row.names = has_rownames(x)) data.table::fwrite(x, ..., sep = sep, row.names = row.names)
fs$dl = function(dt, group.by = NULL, label = T, label.size = 6, shuffle = T, cells.highlight = NULL, raster = ncol(dt) > 20000, ...) suppressMessages(DimPlot(dt, group.by = group.by, label = label, label.size = label.size, shuffle = shuffle, cells.highlight = cells.highlight, raster = raster, ...))
fs$fl = function(dt, gs, order = T, raster = ncol(dt) > 20000, ncol = rep(1:4, c(1, 3, 5, 7))[len(gs)], ...) suppressMessages(FeaturePlot(dt, gs, order = order, ncol = ncol, raster = raster, ...))
fs$vl = function(dt, gs, group.by = NULL, pt.size = 0, ...) VlnPlot(dt, gs, group.by = group.by, pt.size = pt.size, ...)
fs$dtl = function(dt, gs, ...) DotPlot(dt, features = gs, ...) + RotateAxis()
fs$crl = function(corr, col = colorRampPalette(c("#67001F", "#B2182B", "#D6604D", "#F4A582", "#FDDBC7", "#FFFFFF", "#D1E5F0", "#92C5DE", "#4393C3", "#2166AC", "#053061") %>% rev)(200), ...) corrplot::corrplot(corr, col = col, ...)
fs$sl = . %>% unlist %>% sort %>% asl
attach(fs)

dt=readRDS('data/dte.columnar.1w1.new.rds')

dl(dt)

dt %<>% .[,Idents(.)!=15]

dt %<>% FindVariableFeatures %>% ScaleData %>% RunPCA %>% FindNeighbors(dims=1:20) %>% FindClusters %>% RunUMAP(dims=1:20)

dt %<>% .[,Idents(.)!=11]

dt %<>% FindVariableFeatures %>% ScaleData %>% RunPCA %>% FindNeighbors(dims=1:20) %>% FindClusters %>% RunUMAP(dims=1:20)

# e=future(saveRDS(dt,'data/dte.columnar.1w1.new.211129.rds'))
dt=readRDS('data/dte.columnar.1w1.new.211129.rds')

dt$lesion=dt$sam %>% str_remove('_.*') %>% fct_relevel(~.[c(1,3,4,2)])

dl(dt,'RNA_snn_res.0.8')

Idents(dt) = dt$RNA_snn_res.0.8
dt %<>% RenameIdents(
'0'='PC_1',
'1'='PMC_1',
'2'='PC_2',
'3'='PMC_6',
'4'='PMC_3',
'5'='PMC_2',
'6'='GMC_1',
'7'='PMC_4',
'8'='GMC_2',
'9'='PMC_m6',
'10'='PMC_m1',
# '11'='DYS',
'11'='PMC_5',
'12'='PC_3'
)
dt$ident1 = Idents(dt)

rp(6,5)
dl(dt)
# ggsave('../Figure/SupplementaryFigure/SupplementaryFigure4/S4c.png',width=6,height=5)
rp()



a=fread('out/marker.nc.txt')

a %<>% scn(cn(.) %>% make.unique)

b=list(
    a$Genes,
    a$Genes.1,
    a$Genes.2,
    a$Genes.3,
    a$Genes.4,
    a$Genes.5) %>% map(~.[1:100]) %>% sn(s('EpiC ',1:6))

bb=ms %>% map(~.x %>% filter(.[2]>0) %>% rn %>% .[1:100]) %>% .[order(nm(.))]

mat=map_df(b,~{
    i=.x
    map_df(bb,~len(sec(i,.x)))
},.id='rn') %>% c2rn('rn')

rp(6,4)
mat %>% pheatmap::pheatmap(cluster_rows = F,angle_col = 45,cluster_cols = F,
                           display_numbers=T,fontsize_number = 14,number_format = '%.0f')
# mat %>% asm %>% crl(is.corr=F,method=c('number'))
# mat %>% asm %>% crl(is.corr=F,method=c('circle'))
rp()

fl(dt,'Krtdap')

fl(dt,'Lgals2')

fl(dt,'Pdia2')



rp(6, 4)
tb(dt$identtmp, dt$lesion) %>% sweep(2, colSums(.), "/") %>% asdf %>% #filter(asi(x) %in% c(6)) %>% 
# ggplot(aes(x = Var2, y = Freq, group = x, fill = x)) + geom_bar(stat = "identity") + 
ggplot(aes(x = Var2, y = Freq, group = x, color = x)) + geom_line() + geom_point() + 
theme_classic(16) + xlab("Month") + ylab("Proportion")
rp()

rp(6, 4)
p1=tb(dt$identtmp, dt$lesion) %>% sweep(2, colSums(.), "/") %>% asdf %>% filter(asc(x) %in% c('VEC')) %>% 
# ggplot(aes(x = Var2, y = Freq, group = x, fill = x)) + geom_bar(stat = "identity") + 
ggplot(aes(x = Var2, y = Freq, group = x, color = x)) + geom_line() + geom_point() + 
theme_classic(16) + xlab("Month") + ylab("Proportion")
rp()

theme_black = function(base_size = 20, ...) theme_classic(base_size = base_size, ...) + 
    theme(axis.text = element_text(color = "black"), 
          line = element_line(size = 0.5), 
          rect = element_rect(size = 0.5), 
          legend.margin = margin(0,0,0,0),
          plot.title = element_text(hjust = 0.5, face = "bold"))

rp(6,5)
vl(dt,'VEG1',group.by='lesion')+geom_boxplot(width=.2)+theme_black()+NoLegend()+RotateAxis(0)+xlab('')+ggtitle('VEC Score')
# ggsave('../Figure/SupplementaryFigure/SupplementaryFigure7/S7g.png',width=6,height=5)
rp()



DefaultAssay(dt)='RNA'

gs=fread('../nmf/result/GLDYS.txt',header=T)%>% .[1:50,]

dt %<>% AddModuleScore(list(gs$GLDYS_M10 %>% str_to_title),name = 'VEC')

fl(dt,'VEC1')+scale_color_gradientn(colors=scales::brewer_pal(palette = 'RdYlGn',direction = -1)(11))

rp(5,5)
# fl(dt,'VEC1',pt.size=4,min.cutoff=0,raster=T)+scale_color_gradientn(colors=scales::brewer_pal(palette = 'RdYlGn',direction = -1)(9))+ggtitle('VEC Score') + 
fl(dt,'VEC1',pt.size=4,raster=T)+scale_color_gradientn(colors=scales::brewer_pal(palette = 'RdYlGn',direction = -1)(11))+ggtitle('VEC Score') + 
theme_black(20)
# theme(legend.text = element_text(size = 16),
#       plot.title=element_text(size=24),
#                  # legend.position = 'right',
#                  # legend.key.height = unit(1.4,"cm"),
#                  # legend.key.width = unit(1.4,"cm"),
#                  axis.text.x = element_text(size = 16),
#                  axis.text.y = element_text(size = 16),
#                  axis.title.x = element_text(size = 20),
#                  axis.title.y = element_text(size = 20))
# rp()
# ggsave('../Figure/ArticleFigure/Figure3/3g.pdf',width=5,height=5)
# ggsave('../Figure/ArticleFigure/Figure3/3g.png',width=5,height=5)





gsva=readRDS('data/gsva.columnar.new.rds')

gsva %<>% srn(rn(.) %>% str_replace_all('_','-'))

dt[['gsva']]=CreateAssayObject(gsva[,cn(dt)])



DefaultAssay(dt)='gsva'

rp(5,5)
p=fl(dt,'HALLMARK-EPITHELIAL-MESENCHYMAL-TRANSITION',pt.size=4,min.cutoff=0,raster=T)+scale_color_gradientn(colors=scales::brewer_pal(palette = 'RdYlGn',direction = -1)(11))+ggtitle('EMT Score') + 
theme(legend.text = element_text(size = 16),
      plot.title=element_text(size=24),
                 # legend.position = 'right',
                 # legend.key.height = unit(1.4,"cm"),
                 # legend.key.width = unit(1.4,"cm"),
                 axis.text.x = element_text(size = 16),
                 axis.text.y = element_text(size = 16),
                 axis.title.x = element_text(size = 20),
                 axis.title.y = element_text(size = 20))
p
rp()
# ggsave('../Figure/SupplementaryFigure/SupplementaryFigure4/S4a.png',width=6,height=5)



dt@misc$markers$VEC

# o2n = fread("~/lab/data.sync/o2n.hg19.txt") %>% { function(x) mpv(x, .[[1]], .[[2]], F) }
# o2n = fread("~/lab/data.sync/o2n.") %>% { function(x) mpv(x, .[[1]], .[[2]], F) }
db.H50 = msigdbr::msigdbr(species = "Mus musculus", category = "H") %>% select(gs_name, gene_symbol)
# db.cm = fread("http://biocc.hrbmu.edu.cn/CellMarker/download/Mouse_cell_markers.txt") %>% transmute(gs = s(.[[2]], "-", .[[6]]), gene = cellMarker) %>% separate_rows(gene, sep = ", ")
# db.go = msigdbr::msigdbr(species = "Mus musculus", subcategory = "GO:BP") %>% bind_rows(msigdbr::msigdbr(species = "Mus musculus", subcategory = "GO:MF")) %>%bind_rows(msigdbr::msigdbr(species = "Mus musculus", subcategory = "GO:CC")) %>% select(gs_name, gene_symbol)
# db.kegg = msigdbr::msigdbr(species = "Mus musculus", subcategory = "CP:KEGG") %>% select(gs_name, gene_symbol)
# m=dt@misc$markers$VEC %>% filter(avg_log2FC > 0 & p_val_adj < 0.01)
# df=m %>% { sn(.$avg_log2FC, rn(.)) } %>% .[!is.na(nm(.))] %>% sort(T) %>% clusterProfiler::GSEA(TERM2GENE = db.H50, minGSSize = 1) %>% asdf %>% .[,-c(1,2)]
df=dt@misc$markers$VEC %>% filter(avg_log2FC > 0 & p_val_adj < 0.01) %>% rn %>% head(100) %>% #o2n %>%
    clusterProfiler::enricher(TERM2GENE = db.H50, minGSSize = 1) %>% asdf %>% .[,-c(1,2)]

df

df1=df %>% .[c(3,4,8,9),] %>% rn2c('rn')

df1

theme_black = function(base_size = 20, ...) theme_classic(base_size = base_size, ...) + 
    theme(axis.text = element_text(color = "black"), 
          line = element_line(size = 0.5), 
          rect = element_rect(size = 0.5), 
          legend.margin = margin(0,0,0,0),
          plot.title = element_text(hjust = 0.5, face = "bold"))

colors = scales::brewer_pal(palette = 8)(4) %>% rev # %>% scales::show_col()
rp(12, 5)
# df = enrich.H50 %>% asdf %>% .[1:6, -c(1, 2)] %>% r2c
p2=ggplot(df1, aes(x = factor(rn, levels = rn %>% rev), y = -log(p.adjust), fill = -log(p.adjust))) +
    geom_bar(stat = 'identity', fill = colors) +
    coord_flip() +
    theme_black(20) +
    theme(axis.text.y = element_blank()) +
    NoLegend() +
    xlab('') +
    annotate('text', x = 1:4 %>% rev, y = 0.1, label = df1$rn, hjust = 0, vjust = 0.5,size=5) 
(p2 | p) + plot_layout(widths=c(7,5))
# ggsave('../Figure/SupplementaryFigure/SupplementaryFigure8/S8g.png',width=12,height=5)
rp()




